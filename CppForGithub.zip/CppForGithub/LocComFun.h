﻿#pragma once
#ifndef H_LOC_COM_FUN_H
#define H_LOC_COM_FUN_H

//--------------------------------------------------------------------------------
// Header file include
//--------------------------------------------------------------------------------
#define WIN32_LEAN_AND_MEAN		// 

#include <stdio.h>
#include <tchar.h>
#include <cstdlib>
#include <cstdio>
#include <cmath>

//#define NOMINMAX
#include <windows.h>
#include <process.h>
#include <direct.h>
#include "iomanip"
#include <io.h>
#include <time.h>
#include <cstring>
#include <sstream>
#include <iostream>
#include <fstream> 

#include <vector>
#include <stack>
#include <string>
#include <set>
#include <map>
#include <bitset>
#include <Algorithm>
#include <numeric>
#include <omp.h>

#include <direct.h>
#include <math.h>
#include <stdlib.h>
#include <ctime>
#include <time.h>
#include <random>

#include <pcl/point_types.h>
#include <pcl/point_cloud.h>
#include <pcl/io/pcd_io.h>
#include <pcl/io/ply_io.h>
#include <pcl/filters/filter.h>
#include <pcl/visualization/pcl_visualizer.h>

#include <pcl/search/kdtree.h>
#include <pcl/search/search.h>
#include <pcl/registration/ndt.h>
#include <pcl/registration/transforms.h>
#include <pcl/filters/approximate_voxel_grid.h>   
#include <pcl/filters/voxel_grid.h>

#include "pcl\common\centroid.h"
#include "pcl\common\impl\centroid.hpp"

//// Eigen. 
#include <Eigen/src/Core/DenseBase.h>
#include <Eigen/src/Geometry/Transform.h>
#include <Eigen/src/Geometry/EulerAngles.h>
#include <Eigen/src/Geometry/Quaternion.h>
#include <Eigen/src/Geometry/AngleAxis.h>
#include <Eigen/src/LU\FullPivLU.h>
#include <Eigen/src/LU/Determinant.h>
#include <Eigen/src/LU/InverseImpl.h>
#include <Eigen/src/LU/PartialPivLU.h>

using namespace std;
//
#include <winsock2.h>
#pragma comment(lib,"WS2_32")

typedef Eigen::Matrix< double, Eigen::Dynamic, Eigen::Dynamic> MatXX;
typedef Eigen::Matrix< double, 4, Eigen::Dynamic> Vec4X;
typedef Eigen::Matrix< double, 3, Eigen::Dynamic> Vec3X;
typedef Eigen::Matrix< double, 1, Eigen::Dynamic> Vec1X;
typedef Eigen::Matrix< double, 6, 1> Vec6d;
typedef Eigen::Matrix< double, 3, 1> Vec3d;
typedef Eigen::Matrix< double, 4, 1> Vec4d;
typedef Eigen::Matrix< double, 6, 6> Mat6d;
typedef Eigen::Matrix< double, 3, 6> Mat36;
typedef Eigen::Matrix< double, 6, 3> Mat63;
typedef Eigen::Matrix< double, 3, 3> Mat3d;
typedef Eigen::Matrix< double, 4, 4> Mat4d;

typedef Eigen::Matrix< float , 3, 1> Vec3f;
typedef Eigen::Matrix< float , 3, 3> Mat3f;

//-----------------------------------------------------------------
//
//-----------------------------------------------------------------
inline
Mat3d SkewD(const Vec3d& vA)
{
	Mat3d TmpTF = Mat3d::Zero();
	TmpTF(0, 1) = -vA(2);
	TmpTF(0, 2) = vA(1);
	TmpTF(1, 0) = vA(2);
	TmpTF(1, 2) = -vA(0);
	TmpTF(2, 0) = -vA(1);
	TmpTF(2, 1) = vA(0);
	return TmpTF;
}
//-----------------------------------------------------------------
//
//-----------------------------------------------------------------
inline
Vec3d CRot2Eul(const Mat3d& R) 		//	It is same to matlab 
{
	Vec3d E = Eigen::Vector3d::Zero();
	double sy = sqrt(R(0, 0) * R(0, 0) + R(1, 0) * R(1, 0));
	bool singular = (sy < 10e-10) ? true : false;
	Vec3d tEuler;
	if (!singular) {
		tEuler(0) = atan2(R(2, 1), R(2, 2));	//	x
		tEuler(1) = atan2(-R(2, 0), sy);		//	y
		tEuler(2) = atan2(R(1, 0), R(0, 0));	//	z
	}
	else {
		tEuler(0) = atan2(-R(1, 2), R(1, 1));
		tEuler(1) = atan2(-R(2, 0), sy);
		tEuler(2) = 0;
	}
	//std::cout << "tEuler<Z-Y-X> is :\n" << tEuler.transpose() << std::endl;
	E(0) = tEuler(2);
	E(1) = tEuler(1);
	E(2) = tEuler(0);
	return E;
}
//-----------------------------------------------------------------
//
//-----------------------------------------------------------------
inline
Mat3d CEul2Rot(const Vec3d& theta) //	Z -> Y -> X	
{
	double yaw = theta(0);		// z
	double pitch = theta(1);
	double roll = theta(2);
	Eigen::AngleAxisd yawAngle(yaw, Eigen::Vector3d::UnitZ());		//	Z
	Eigen::AngleAxisd pitchAngle(pitch, Eigen::Vector3d::UnitY());	//	Y
	Eigen::AngleAxisd rollAngle(roll, Eigen::Vector3d::UnitX());	//	X
	Eigen::Quaterniond q = yawAngle * pitchAngle * rollAngle;
	Mat3d R = q.matrix();
	return R;
}
//-----------------------------------------------------------------
//
//-----------------------------------------------------------------
inline
Mat4d CPose2TF(const Vec6d& Pose)
{
	Mat4d tmpTF = Eigen::Matrix4d::Identity();
	tmpTF.block<3, 3>(0, 0) = CEul2Rot(Pose.block<3, 1>(3, 0));
	tmpTF.block<3, 1>(0, 3) = Pose.block<3, 1>(0, 0);
	return tmpTF;
}
inline
Vec6d CTF2Pose(const Mat4d& TF)
{
	Vec6d Pose;
	Pose.block<3, 1>(0, 0) = TF.block<3, 1>(0, 3);
	Pose.block<3, 1>(3, 0) = CRot2Eul(TF.block<3, 3>(0, 0));
	return Pose;
}
//-----------------------------------------------------------------
//
//-----------------------------------------------------------------
inline
Vec6d CPose2State(const Vec6d& Pose) // x, y, z, az, ay, ax
{
	Vec6d State;	//	ax, ay, az, x, y, z
	State(0) = Pose(5);
	State(1) = Pose(4);
	State(2) = Pose(3);
	State(3) = Pose(0);
	State(4) = Pose(1);
	State(5) = Pose(2);
	return State;
}
inline
Vec6d CState2Pose(const Vec6d& State) // ax, ay, az, x, y, z
{
	Vec6d Pose;		// x, y, z, az, ay, ax
	Pose(5) = State(0);
	Pose(4) = State(1);
	Pose(3) = State(2);
	Pose(0) = State(3);
	Pose(1) = State(4);
	Pose(2) = State(5);
	return Pose;
}
inline
Mat4d CState2TF(const Vec6d& State)
{
	return CPose2TF(CState2Pose(State));
}
inline
Vec6d CTF2State(const Mat4d& TF)
{
	return CPose2State(CTF2Pose(TF));
}
//-----------------------------------------------------------------
//
//-----------------------------------------------------------------
inline
void MatSizeShow(const MatXX& M)
{
	std::cout << "[" << M.rows() << ", " << M.cols() << "]" << std::endl;
}
//
inline
void MatShow(const MatXX& M)
{
	std::cout << "-----------------------------------" << std::endl;
	std::cout << M << std::endl;
	std::cout << "-----------------------------------" << std::endl;
}
//
inline
std::string VecShowD(const Vec3d& V)
{
	char tmpStr[200] = " ";
	sprintf(tmpStr, "[%.10f, %.10f, %.10f]", V(0), V(1), V(2));
	return std::string(tmpStr);
}
inline
std::string Vec6dShow(const Vec6d& V)
{
	char tmpStr[200] = " ";
	sprintf(tmpStr, "[%.10f, %.10f, %.10f %.10f, %.10f, %.10f]", V(0), V(1), V(2), V(3), V(4), V(5));
	return std::string(tmpStr);
}
//
inline
void vVecShow(const std::vector<Vec4d>& vVecM)
{
	size_t Len = vVecM.size();
	for (size_t i = 0; i < Len; i++)
	{
		std::cout << vVecM[i].transpose() << std::endl;
	}
}
//-----------------------------------------------------------------
//
//-----------------------------------------------------------------
inline
double SEdistT(const Vec6d& GrdPose, const Vec6d& LocPose)
{
	Vec3d tmpA;
	tmpA(0) = GrdPose(0);
	tmpA(1) = GrdPose(1);
	tmpA(2) = GrdPose(2);
	Vec3d tmpB;
	tmpB(0) = LocPose(0);
	tmpB(1) = LocPose(1);
	tmpB(2) = LocPose(2);
	return (tmpA - tmpB).norm();
}
inline
double SEdistR(const Vec6d& GrdPose, const Vec6d& LocPose)
{
	Vec3d tmpA;
	tmpA(0) = GrdPose(3);
	tmpA(1) = GrdPose(4);
	tmpA(2) = GrdPose(5);
	Mat3d ATF = CEul2Rot(tmpA);
	Vec3d tmpB;
	tmpB(0) = LocPose(3);
	tmpB(1) = LocPose(4);
	tmpB(2) = LocPose(5);
	Mat3d BTF = CEul2Rot(tmpB);
	Mat3d dTF = ATF.inverse() * BTF;
	return std::acos((dTF.trace() - 1.0) / 2.0);
}
//-----------------------------------------------------------------
//
//-----------------------------------------------------------------
inline
double warpTo2Pi(const double& lambda)
{
	bool tmpB = lambda > 0.0;
	double tmpV = 0.0;
	tmpV = std::fmod(lambda, 2.0 * M_PI);
	if ((lambda == 0.0) && (tmpB))
	{
		tmpV = 2.0 * M_PI;
	}
	return tmpV;
}
//
inline
double warpToPi(const double& lambda)
{
	double tmpV = lambda;
	if ((lambda < -M_PI) || (M_PI < lambda))
	{
		tmpV = warpTo2Pi(lambda + M_PI) - M_PI;
	}
	return tmpV;
}
//-----------------------------------------------------------------
//
//-----------------------------------------------------------------
template<typename TypeT>
inline
TypeT CalMean(const std::vector<TypeT>& vData)
{
	TypeT sum = std::accumulate(vData.begin(), vData.end(), (double)0.0f); // 
	return sum / ((double)vData.size());
}
template<typename TypeT>
inline
TypeT CalVar(const std::vector<TypeT>& vData)
{
	TypeT var = 0.0;
	TypeT mu = CalMean(vData);
	for (size_t i = 0; i < vData.size(); i++)
	{
		var = var + std::pow(vData[i] - mu, 2);
	}
	return var / (vData.size() - 1.0f);
}
//---------------------------------------------------------
inline
Mat3d CovModif(const Mat3d& oldCov)
{
	double eigenValueRatio = 100.0;
	Eigen::MatrixXd newCov = oldCov;
	//Eigen::EigenSolver<Eigen::MatrixXd> eig(oldCov);// the order is inverse.
	Eigen::SelfAdjointEigenSolver<Eigen::MatrixXd> eig(oldCov, Eigen::ComputeEigenvectors);
	Eigen::MatrixXd V = eig.eigenvectors().real();
	Eigen::MatrixXd D = eig.eigenvalues().real();

	double maxEv = D.maxCoeff();
	Eigen::MatrixXd mD = eigenValueRatio * D;
	if ((maxEv >= mD(0, 0)) || (maxEv >= mD(1, 0)) || (maxEv >= mD(2, 0)))
	{
		double tmpV1 = maxEv / eigenValueRatio;
		if (maxEv >= mD(0, 0)) { D(0, 0) = tmpV1; }
		if (maxEv >= mD(1, 0)) { D(1, 0) = tmpV1; }
		if (maxEv >= mD(2, 0)) { D(2, 0) = tmpV1; }
		Eigen::MatrixXd tmpM1 = V * V.transpose() - Mat3d::Identity();
		Eigen::MatrixXd iV = V.transpose();
		if (tmpM1.cwiseAbs().maxCoeff() < 2.22044604925031e-15) // 10*eps(class(J))
		{
			iV = V.transpose();
		}
		else
		{
			iV = V.inverse();
		}
		
		newCov = V * D.asDiagonal() * iV;
	}
	return newCov;
}
//---------------------------------------------------------
inline
Mat3d myCovModif(const Mat3d& oldCov)
{   // Avoid matrice near singularities (eq 6.11) [Magnusson 2009]
	double eigenValueRatio = 100.0;
	Eigen::MatrixXd newCov = oldCov;
	Eigen::SelfAdjointEigenSolver<Eigen::Matrix3d> eig;
	eig.compute(oldCov);
	Eigen::Matrix3d V = eig.eigenvectors().real();
	Eigen::Matrix3d D = eig.eigenvalues().asDiagonal();

	double maxEv = D(2, 2); // D.maxCoeff();
	Eigen::Matrix3d mD = eigenValueRatio * D;
	if ((maxEv >= mD(0, 0)) || (maxEv >= mD(1, 1)) || (maxEv >= mD(2, 2)))
	{
		double tmpV1 = maxEv / eigenValueRatio;
		if (maxEv >= mD(0, 0)) { D(0, 0) = tmpV1; }
		if (maxEv >= mD(1, 1)) { D(1, 1) = tmpV1; }
		if (maxEv >= mD(2, 2)) { D(2, 2) = tmpV1; }
		Eigen::MatrixXd tmpM1 = V * V.transpose() - Mat3d::Identity();
		Eigen::MatrixXd iV = V.transpose();
		if (tmpM1.cwiseAbs().maxCoeff() < 2.22044604925031e-15) // 10*eps(class(J))
		{
			iV = V.transpose();
		}
		else
		{
			iV = V.inverse();
		}
		newCov = V * D * iV;
	}
	return newCov;
}
inline
Mat3d CalCov(const pcl::PointCloud<pcl::PointXYZ>::Ptr& Cloud, std::vector<int>& k_Ind)
{	// compared to myCalCov(), this function is more faster.
	Mat3d covMat;
	Eigen::Matrix<double, 4, 1> centroid;
	pcl::compute3DCentroid(*Cloud, k_Ind, centroid);
	pcl::computeCovarianceMatrixNormalized(*Cloud, k_Ind, centroid, covMat);
	return CovModif(covMat);
}
inline
Mat3d myCalCov(const pcl::PointCloud<pcl::PointXYZ>::Ptr& Cloud, std::vector<int>& k_Ind)
{
	Vec3d center;
	center << 0.0, 0.0, 0.0;
	std::vector<Vec3d> vPts;
	for (size_t i = 0; i < k_Ind.size(); i++)
	{
		Vec3d tmpPt;
		tmpPt(0) = (double)Cloud->points[k_Ind[i]].x;
		tmpPt(1) = (double)Cloud->points[k_Ind[i]].y;
		tmpPt(2) = (double)Cloud->points[k_Ind[i]].z;
		vPts.push_back(tmpPt);
		center = center + tmpPt;
	}

	center = center / ((double)k_Ind.size());

	Eigen::MatrixXd mp;
	mp.resize(vPts.size(), 3);
	for (size_t i = 0; i < vPts.size(); i++)
	{
		Vec3d tmpPt = vPts[i];
		mp.block<1, 3>(i, 0) = (tmpPt - center).transpose();
	}
	Mat3d covMat = (mp.transpose() * mp) / ((double)(vPts.size() - 1));
	return myCovModif(covMat);
}
//---------------------------------------------------------
template<typename TypeT>
inline
pcl::PointCloud<TypeT> pcread(const std::string &FileName)
{
	pcl::PointCloud<TypeT> pcData;
	if (pcl::io::loadPCDFile<TypeT>(FileName.c_str(), pcData) < 0) 
	{
		std::cout << "Cannot get the " << FileName << ".pcd file!" << std::endl;
		exit(-1);
	}
	pcData.width = pcData.size();
	pcData.height = 1;
	pcData.is_dense = false;
}
//----------------------------------------------------------------------------------------
//	
//----------------------------------------------------------------------------------------

inline
Eigen::Matrix4d CTQ2TF(const std::vector<double>& vTQ) {
	Eigen::Matrix4d tfrom = Eigen::Matrix4d::Identity();
	tfrom(0, 3) = vTQ[0];
	tfrom(1, 3) = vTQ[1];
	tfrom(2, 3) = vTQ[2];
	tfrom(3, 3) = 1.0;
	Eigen::Quaterniond q;	//	<x,y,z,w>
	q.x() = vTQ[3];
	q.y() = vTQ[4];
	q.z() = vTQ[5];
	q.w() = vTQ[6];
	Eigen::Matrix3d R = q.normalized().toRotationMatrix();
	tfrom.block<3, 3>(0, 0) = R;
	return tfrom;
}
//----------------------------------------------------------------------------------------
//	
//----------------------------------------------------------------------------------------
inline double CAng2Rad(const double  Ang) { return Ang * (M_PI / 180); }
inline double CRad2Ang(const double  Rad) { return Rad * (180 / M_PI); }
//----------------------------------------------------------------------------------------
//	
//----------------------------------------------------------------------------------------
inline
void CNormalToXYZ(const pcl::PointCloud<pcl::PointNormal>::Ptr& PCNormal, pcl::PointCloud<pcl::PointXYZ>::Ptr& PCXYZ)
{
	PCXYZ->clear();
	pcl::PointXYZ tmpPt;
	// Iterate over each point
	for (size_t i = 0; i < PCNormal->size(); ++i) {
		tmpPt.x = PCNormal->points[i].x;
		tmpPt.y = PCNormal->points[i].y;
		tmpPt.z = PCNormal->points[i].z;
		PCXYZ->push_back(tmpPt);
	}
	PCXYZ->width = PCNormal->width;
	PCXYZ->height = PCNormal->height;
	PCXYZ->is_dense = PCNormal->is_dense;
}
//------------------------------------------------------------------------------------------------
//
//------------------------------------------------------------------------------------------------
inline
pcl::PointCloud<pcl::PointXYZ>::Ptr DownRandom(const pcl::PointCloud<pcl::PointXYZ>::Ptr& InaPtr, const double Res) {
	pcl::PointCloud<pcl::PointXYZ>::Ptr OutPtr(new pcl::PointCloud<pcl::PointXYZ>);
	for (size_t i = 0; i < InaPtr->points.size(); i++) {
		if (rand() / double(RAND_MAX) <= Res) {
			OutPtr->points.push_back(InaPtr->points[i]);
		}
	}
	OutPtr->is_dense = InaPtr->is_dense;
	OutPtr->sensor_origin_ = InaPtr->sensor_origin_;
	OutPtr->sensor_orientation_ = InaPtr->sensor_orientation_;
	OutPtr->header = InaPtr->header;
	OutPtr->width = OutPtr->points.size();
	OutPtr->height = 1;
	return OutPtr;
}

//------------------------------------------------------------------------------------------------
//
//------------------------------------------------------------------------------------------------
inline
pcl::PointCloud<pcl::PointXYZ>::Ptr DownGird(const pcl::PointCloud<pcl::PointXYZ>::Ptr& cloud, const double& dGridSize)
{
	if (dGridSize < 0)   // do not subsampling.
	{
		return NULL;
	}
	pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_subsampled(new pcl::PointCloud<pcl::PointXYZ>);
	pcl::VoxelGrid<pcl::PointXYZ> Voxel_filter;
	Voxel_filter.setLeafSize(dGridSize, dGridSize, dGridSize);
	Voxel_filter.setInputCloud(cloud);
	Voxel_filter.filter(*cloud_subsampled);

	cloud_subsampled->is_dense = cloud->is_dense;
	cloud_subsampled->sensor_origin_ = cloud->sensor_origin_;
	cloud_subsampled->sensor_orientation_ = cloud->sensor_orientation_;
	cloud_subsampled->header = cloud->header;
	cloud_subsampled->width = cloud_subsampled->size();
	cloud_subsampled->height = 1;
	return cloud_subsampled;
}
//------------------------------------------------------------------------------------------------
//
//------------------------------------------------------------------------------------------------
inline
pcl::PointCloud<pcl::PointXYZ>::Ptr LimitRange(const pcl::PointCloud<pcl::PointXYZ>::Ptr& cloud, const double& MinR, const double& MaxR)
{
	if ((MinR < 0.0) || (MaxR < MinR))   // do not subsampling.
	{
		return NULL;
	}
	pcl::PointCloud<pcl::PointXYZ>::Ptr CloudOut_Ptr(new pcl::PointCloud<pcl::PointXYZ>);
	size_t Len = cloud->points.size();
	for (size_t i = 0; i < Len; i++)
	{
		pcl::PointXYZ tmpt = cloud->points[i];
		double tmpR = std::sqrt(tmpt.x * tmpt.x + tmpt.y * tmpt.y + tmpt.z * tmpt.z);
		if ((tmpR < MinR) || (tmpR > MaxR))
		{
			continue;
		}
		CloudOut_Ptr->points.push_back(tmpt);
	}
	CloudOut_Ptr->is_dense = cloud->is_dense;
	CloudOut_Ptr->sensor_origin_ = cloud->sensor_origin_;
	CloudOut_Ptr->sensor_orientation_ = cloud->sensor_orientation_;
	CloudOut_Ptr->header = cloud->header;
	CloudOut_Ptr->width = CloudOut_Ptr->size();
	CloudOut_Ptr->height = 1;
	return CloudOut_Ptr;
}
//------------------------------------------------------------------------------------------------
//
//------------------------------------------------------------------------------------------------
inline
pcl::PointCloud<pcl::PointNormal>::Ptr RemoveNaNFromPC(const pcl::PointCloud<pcl::PointNormal>::Ptr& InaPtr)
{
	pcl::PointCloud<pcl::PointNormal>::Ptr OutPtr(new pcl::PointCloud<pcl::PointNormal>);
	for (size_t i = 0; i < InaPtr->points.size(); i++)
	{
		pcl::PointNormal tmpPt = InaPtr->points[i];

		if ((!pcl_isfinite(tmpPt.x)) || (!pcl_isfinite(tmpPt.y)) || (!pcl_isfinite(tmpPt.z))
			|| (!pcl_isfinite(tmpPt.normal_x)) || (!pcl_isfinite(tmpPt.normal_y)) || (!pcl_isfinite(tmpPt.normal_z)))
		{
			continue;
		}
		OutPtr->points.push_back(tmpPt);
	}
	OutPtr->header = InaPtr->header;
	OutPtr->width = OutPtr->size();
	OutPtr->height = 1;
	OutPtr->is_dense = InaPtr->is_dense;
	OutPtr->sensor_orientation_ = InaPtr->sensor_orientation_;
	OutPtr->sensor_origin_ = InaPtr->sensor_origin_;
	return OutPtr;
}
//------------------------------------------------------------------------------------------------
//
//------------------------------------------------------------------------------------------------
inline
pcl::PointCloud<pcl::PointXYZ>::Ptr SelSubPtsP2P(const pcl::PointCloud<pcl::PointXYZ>::Ptr& fullPC, const std::vector<int>& indices)
{
	pcl::PointCloud<pcl::PointXYZ>::Ptr partPC(new pcl::PointCloud<pcl::PointXYZ>);
	if (indices.size() == fullPC->points.size())
	{
		return fullPC;
	}
	// Iterate over each point
	for (size_t i = 0; i < indices.size(); ++i)
	{
		partPC->push_back(fullPC->points[indices[i]]);
	}
	// Allocate enough space and copy the basics
	partPC->header = fullPC->header;
	partPC->width = partPC->size();
	partPC->height = 1;
	partPC->is_dense = fullPC->is_dense;
	partPC->sensor_orientation_ = fullPC->sensor_orientation_;
	partPC->sensor_origin_ = fullPC->sensor_origin_;
	return partPC;
}

//---------------------------------------------------------------------------------------
//	
//---------------------------------------------------------------------------------------
inline
int SaveHdlPCD(const std::string& FileName,
	const std::string& MainFolder,
	const pcl::PointCloud<pcl::PointXYZ>::Ptr& SaveHdlPtr,
	const unsigned nFrm) {
	char PLYDir[200] = "\0";
	sprintf_s(PLYDir, "%s\\%sPCD\\", MainFolder.c_str(), FileName.c_str());
	if (_access(PLYDir, 0) != 0) {
		if (_mkdir(PLYDir) != 0) {
			std::cout << "Error : Output Folder is not Created!" << std::endl;
			exit(-1);
		}
	}
	char PLYName[200] = "\0";
	sprintf_s(PLYName, "%s%s%06d.pcd", PLYDir, FileName.c_str(), nFrm);
	pcl::io::savePCDFileBinaryCompressed(PLYName, *SaveHdlPtr);
	return 1;
}
void SaveVec6dPose(const std::string& FileName, const std::vector<Vec6d>& vLocPose)
{
	std::ofstream LocLog;
	LocLog.open(FileName.c_str());
	for (size_t i = 0; i < vLocPose.size(); i++)
	{
		LocLog << i << "  " << vLocPose[i].transpose() << std::endl;
	}
	LocLog.close();
}
//------------------------------------------------------------------------------------------------
//	knn search function
//------------------------------------------------------------------------------------------------
inline
pcl::PointXYZ KnnSearch(const pcl::PointCloud<pcl::PointXYZ>::Ptr& vPts, const pcl::PointXYZ& searchPoint)
{
	pcl::KdTreeFLANN<pcl::PointXYZ>::Ptr SearchTreePtr(new pcl::KdTreeFLANN<pcl::PointXYZ>);
	SearchTreePtr->setInputCloud(vPts);
	std::vector<int> k_Ind;
	std::vector<float> k_Dist;
	SearchTreePtr->nearestKSearch(searchPoint, 1, k_Ind, k_Dist);
	return vPts->points[k_Ind[0]];    // 
}
//------------------------------------------------------------------------------------------------
//	Radius search function
//------------------------------------------------------------------------------------------------
inline
pcl::PointCloud<pcl::PointXYZ>::Ptr RadSearch(const pcl::PointCloud<pcl::PointXYZ>::Ptr& vPts, const pcl::PointXYZ& searchPoint, const double Radius)
{
	pcl::KdTreeFLANN<pcl::PointXYZ>::Ptr SearchTreePtr(new pcl::KdTreeFLANN<pcl::PointXYZ>);
	SearchTreePtr->setInputCloud(vPts);
	std::vector<int> k_Ind;
	std::vector<float> k_Dist;
	SearchTreePtr->radiusSearch(searchPoint, Radius, k_Ind, k_Dist);
	pcl::PointCloud<pcl::PointXYZ>::Ptr Tmp(new pcl::PointCloud<pcl::PointXYZ>);
	Tmp = SelSubPtsP2P(vPts, k_Ind);
	return Tmp;    // 
}
//-----------------------------------------------------------------
//
//-----------------------------------------------------------------
inline
void ReadCovFile(const std::string& TxtName, std::vector<Mat3d>& vCov)
{
	std::ifstream ifData;
	ifData.open(TxtName);
	if (!ifData)
	{
		std::cout << "Cannot get the "<< TxtName << " file!" << std::endl;
		exit(-1);
	}
	std::stringstream ss;
	std::string tmpStr;
	Mat3d TmpCov;
	vCov.clear();
	while (!ifData.eof())
	{
		getline(ifData, tmpStr);
		if (tmpStr.empty()) { continue; }
		ss.clear();
		ss.str(tmpStr);
		ss  >> TmpCov(0, 0) >> TmpCov(0, 1) >> TmpCov(0, 2)
			>> TmpCov(1, 0) >> TmpCov(1, 1) >> TmpCov(1, 2)
			>> TmpCov(2, 0) >> TmpCov(2, 1) >> TmpCov(2, 2);
		vCov.push_back(TmpCov);
	}
	ifData.close();
}
//-----------------------------------------------------------------
//
//-----------------------------------------------------------------
#endif
