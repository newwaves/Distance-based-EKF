﻿#pragma once
#ifndef H_AOM_EKF_H
#define H_AOM_EKF_H

#include "LocComFun.h"
#include "LocParams.h"
#include "RobustDist.h"

//---------------------------------------------------------------------------
//	
//---------------------------------------------------------------------------
class CDistanceEKF
{
private:
	CLocPara m_Para;
	int m_nFrm;
	// Distance-based EKF
	Vec6d m_PoseK;		// x, y, z, az, ay, ax
	Vec6d m_StateK;		// ax, ay, az, x, y, z
	Mat4d m_TFK;		// m_TF = [m_R,m_t; 0 0 0 1];
	Mat4d m_TFK_1;
	Mat6d m_CovK;
	Mat6d m_CovK_1;
	Mat6d m_Mk;			// Motion covariance 6 X 1
	double m_Qk;		// Observation covariance
	std::vector<Vec6d> m_vLocPose;	//	save m_PoseK;
	std::vector<Vec6d> m_vImuPose;	//	Get pose
	double m_FitScore;				//	evaluate
	//
	pcl::search::KdTree<pcl::PointXYZ>::Ptr		m_KdHdlP_ptr;
	pcl::PointCloud<pcl::PointXYZ>::Ptr			m_MapP_ptr;		//	
	pcl::search::KdTree<pcl::PointXYZ>::Ptr		m_KdMapP_ptr;	//	calculating the score
	pcl::PointCloud<pcl::PointNormal>::Ptr		m_MapPN_ptr;	//	map normal
	
	std::vector<Vec3d> m_vHdlPts; 
	std::vector<Mat3d> m_vHdlCov;	//	hdl covariances
	std::vector<Vec3d> m_vMapPts; 
	std::vector<Vec3d> m_vMapNor;
	std::vector<Mat3d> m_vMapCov;	//	map covariances
	
	pcl::PointCloud<pcl::PointXYZ>::Ptr m_InaHdl_ptr;	// Raw input pointcloud
	pcl::PointCloud<pcl::PointXYZ>::Ptr m_EKFHdl_ptr;	// for updating the state, keep 2000 points
	pcl::PointCloud<pcl::PointXYZ>::Ptr m_FitHdl_ptr;	// for fitscorefun() 
	pcl::PointCloud<pcl::PointXYZ>::Ptr m_OutTra_ptr;

	////	save log
	//std::ofstream m_LocInfoLog;
	////	DataRoot
	std::string m_LogDir;

	// display
	pcl::visualization::PCLVisualizer m_Viewer;
	std::string m_DisInfo;
	pcl::PointCloud<pcl::PointXYZ>::Ptr m_pGpsPose;
	pcl::PointCloud<pcl::PointXYZ>::Ptr m_pLocPose;
	pcl::PointCloud<pcl::PointXYZ>::Ptr m_GpsShow_ptr;
	pcl::PointCloud<pcl::PointXYZ>::Ptr m_ImuShow_ptr;
	pcl::PointCloud<pcl::PointNormal>::Ptr m_MapShow_ptr;	//
	pcl::PointCloud<pcl::PointXYZ>::Ptr m_InaShow_ptr;
	pcl::PointCloud<pcl::PointXYZ>::Ptr m_TraShow_ptr;
	//-------------------------------------------------------------------------

public:
	CDistanceEKF() {
		setLogDir();
		Init();
		//
		pcl::PointCloud<pcl::PointNormal>::Ptr temp1(new pcl::PointCloud<pcl::PointNormal>);
		m_MapPN_ptr = temp1;
		pcl::PointCloud<pcl::PointXYZ>::Ptr temp2(new pcl::PointCloud<pcl::PointXYZ>);
		m_MapP_ptr = temp2;
		//	living data 
		pcl::PointCloud<pcl::PointXYZ>::Ptr temp3(new pcl::PointCloud<pcl::PointXYZ>);
		m_InaHdl_ptr = temp3; // pcl type
		pcl::PointCloud<pcl::PointXYZ>::Ptr temp4(new pcl::PointCloud<pcl::PointXYZ>);
		m_EKFHdl_ptr = temp4;
		pcl::PointCloud<pcl::PointXYZ>::Ptr temp7(new pcl::PointCloud<pcl::PointXYZ>);
		m_OutTra_ptr = temp7;
		pcl::PointCloud<pcl::PointXYZ>::Ptr temp8(new pcl::PointCloud<pcl::PointXYZ>);
		m_FitHdl_ptr = temp8;
		m_FitScore = 0.0;
		// Hdl KdMod for calculating the covariances of lidar scan points
		pcl::search::KdTree<pcl::PointXYZ>::Ptr searchPtr1(new pcl::search::KdTree<pcl::PointXYZ>);
		m_KdHdlP_ptr = searchPtr1;
		pcl::search::KdTree<pcl::PointXYZ>::Ptr searchPtr2(new pcl::search::KdTree<pcl::PointXYZ>);
		m_KdMapP_ptr = searchPtr2;
		//OpenLogFile();	//	save localization log	save receive pose	save send pose	
		std::cout << "Load map need more time(about 4s), please hold on ...... " << std::endl;
		LoadFullMap();	//	Load Full Map

		//  display
		pcl::PointCloud<pcl::PointXYZ>::Ptr temp11(new pcl::PointCloud<pcl::PointXYZ>);
		m_pGpsPose = temp11;
		pcl::PointCloud<pcl::PointXYZ>::Ptr temp12(new pcl::PointCloud<pcl::PointXYZ>);
		m_pLocPose = temp12;
		pcl::PointCloud<pcl::PointNormal>::Ptr temp13(new pcl::PointCloud<pcl::PointNormal>);
		m_MapShow_ptr = temp13;
		pcl::PointCloud<pcl::PointXYZ>::Ptr temp14(new pcl::PointCloud<pcl::PointXYZ>);
		m_GpsShow_ptr = temp14;
		pcl::PointCloud<pcl::PointXYZ>::Ptr temp15(new pcl::PointCloud<pcl::PointXYZ>);
		m_ImuShow_ptr = temp15;
		pcl::PointCloud<pcl::PointXYZ>::Ptr temp16(new pcl::PointCloud<pcl::PointXYZ>);
		m_InaShow_ptr = temp16;
		pcl::PointCloud<pcl::PointXYZ>::Ptr temp17(new pcl::PointCloud<pcl::PointXYZ>);
		m_TraShow_ptr = temp17;

		m_DisInfo = "\0";
		//InitViewer();

	}
	void setLogDir()
	{
		SYSTEMTIME tStart;  
		GetLocalTime(&tStart);
		char tmpFolder[200] = "D:\\DistEKFRecord\\";
		if (0 != _access(tmpFolder, 0))
		{
			int tmp1 = _mkdir(tmpFolder);
		}
		sprintf(tmpFolder, "%s%04d_%02d_%02d\\", tmpFolder, tStart.wYear, tStart.wMonth, tStart.wDay);
		if (_access(tmpFolder, 0) != 0)
		{
			if (_mkdir(tmpFolder))
			{
				std::cout << "Error: Output Folder is not Created!\n";
				exit(-1);
			}
		}
		char g_LidarFolder[200];
		sprintf(g_LidarFolder, "%sRecord_%4d_%02d_%02d_%02d_%02d_%02d", tmpFolder, tStart.wYear, tStart.wMonth, tStart.wDay,
			tStart.wHour, tStart.wMinute, tStart.wSecond);

		char tmpStr[500] = "\0";
		std::cout << m_Para.m_ObsersCov << std::endl;
		sprintf_s(tmpStr, "%sDist%s%sC", g_LidarFolder, m_Para.m_DistType.c_str(), m_Para.m_CovCType.c_str());

		std::cout << tmpStr << std::endl;
		if (_mkdir(tmpStr))
		{
			std::cout << "Error: Output Folder is not Created!\n";
			exit(-1);
		}
		m_LogDir = std::string(tmpStr);
	}

	~CDistanceEKF() {
		m_vImuPose.clear();
		m_vLocPose.clear();
		clear();
		m_MapPN_ptr->clear();
		m_MapP_ptr->clear();
		//CloseLogFile();
	}
	//	clear once loop
	void clear() {
		m_InaHdl_ptr->clear();
		m_EKFHdl_ptr->clear();
		m_OutTra_ptr->clear();
		m_FitHdl_ptr->clear();
	}
	void Init() {
		m_nFrm = m_Para.m_StartID;
		m_TFK_1 = m_Para.m_StartTF;
		m_CovK_1 = m_Para.m_InitCov.asDiagonal();
		m_TFK = m_TFK_1;				// m_TF = [m_R,m_t; 0 0 0 1];
		m_CovK = m_CovK_1;
		m_StateK = CTF2State(m_TFK);			// ax, ay, az, x, y, z
		m_PoseK = CTF2Pose(m_TFK);				// x, y, z, az, ay, ax
		m_Mk = m_Para.m_MotionCov.asDiagonal();
		m_Qk = m_Para.m_ObsersCov;

		m_vImuPose.clear();
		m_vLocPose.clear();
		m_FitScore = 0.0;
	}
	//-------------------------------------------------------------------------
	pcl::PointCloud<pcl::PointXYZ>::Ptr GetGeneTraPtr() { return m_OutTra_ptr; }
	float GetFitScore() { return m_FitScore; }
	int GetHdlLen() { return m_EKFHdl_ptr->size(); }
	int GetnFrm() { return m_nFrm; }

	void LoadFullMap() 
	{
		char FileName[200];
		sprintf_s(FileName, "%s/%s.pcd", m_Para.m_MapRoot.c_str(), m_Para.m_MapName.c_str());
		std::cout << FileName << std::endl;
		if (pcl::io::loadPCDFile<pcl::PointNormal>(FileName, *m_MapPN_ptr) < 0) {
			std::cout << "Cannot get the HDMap.pcd file!" << std::endl;
			exit(-1);
		}
		m_MapPN_ptr->width = m_MapPN_ptr->size();
		m_MapPN_ptr->height = 1;
		m_MapPN_ptr->is_dense = false;

		std::cout << "Number of Raw Map points is: " << m_MapPN_ptr->size() << std::endl;
		m_MapPN_ptr = RemoveNaNFromPC(m_MapPN_ptr);
		std::cout << "Number of New Map points is: " << m_MapPN_ptr->size() << std::endl;
		CNormalToXYZ(m_MapPN_ptr, m_MapP_ptr);
		m_KdMapP_ptr->setInputCloud(m_MapP_ptr);

		m_vMapPts.clear();
		m_vMapNor.clear();
		for (size_t i = 0; i < m_MapPN_ptr->size(); i++)
		{
			Vec3f tmpPt;
			tmpPt(0) = m_MapPN_ptr->points[i].x;
			tmpPt(1) = m_MapPN_ptr->points[i].y;
			tmpPt(2) = m_MapPN_ptr->points[i].z;
			m_vMapPts.emplace_back(tmpPt.cast<double>());
			tmpPt(0) = m_MapPN_ptr->points[i].normal_x;
			tmpPt(1) = m_MapPN_ptr->points[i].normal_y;
			tmpPt(2) = m_MapPN_ptr->points[i].normal_z;
			m_vMapNor.emplace_back(tmpPt.cast<double>());
		}

		if ((0 == m_Para.m_DistType.compare("pt2d")) || (0 == m_Para.m_DistType.compare("d2d")))
		{
			std::cout << "Start read the covariance file!\t" << std::endl;
			sprintf_s(FileName, "%s/%s.txt", m_Para.m_MapRoot.c_str(), m_Para.m_MapName.c_str());
			ReadCovFile(std::string(FileName), m_vMapCov);
			std::cout << "Read the covariance file is done!\t" << std::endl;
			std::cout << "The size of covariances is "<< m_vMapCov.size() << std::endl;
		}		
		std::cout << "Map information is read successfully!\t" << std::endl;
	}
	//--------------------------------------------------------------------------
	void load(const int nFrm) { // 
		char HdlName[200] = "\0";
		// the number of lidar scan points is 2000.
		sprintf_s(HdlName, "%s/LocDataForPCL/HdlRanD%06d.pcd", m_Para.m_HdlRoot.c_str(), nFrm);
		if (pcl::io::loadPCDFile(HdlName, *m_EKFHdl_ptr) < 0) {//	support single type
			std::cout << "At the End of RandomHdl.txt! " << std::endl;
			exit(-1);
		}
		m_EKFHdl_ptr->width = m_EKFHdl_ptr->size();
		m_EKFHdl_ptr->height = 1;
		m_EKFHdl_ptr->is_dense = false;

		// map density is about 5
		sprintf_s(HdlName, "%s/LocDataForPCL/HdlMD5%06d.pcd", m_Para.m_HdlRoot.c_str(), nFrm);
		if (pcl::io::loadPCDFile(HdlName, *m_InaHdl_ptr) < 0) {//	support single type
			std::cout << "At the End of RandomHdl.txt! " << std::endl;
			exit(-1);
		}
		m_InaHdl_ptr->width = m_InaHdl_ptr->size();
		m_InaHdl_ptr->height = 1;
		m_InaHdl_ptr->is_dense = false;
		//-------------------------------------------------
		if (0 == m_Para.m_DistType.compare("d2d"))
		{
			m_KdHdlP_ptr->setInputCloud(m_InaHdl_ptr);
			m_vHdlCov.clear();
			// CovCNebK  CovCRngR  CovCNdtS(VoxelGrid)
			if (0 == m_Para.m_CovCType.compare("CovCNebK"))
			{
				ScansCovNeibK();
			}
			if (0 == m_Para.m_CovCType.compare("CovCRngR"))
			{
				ScansCovRange();
			}
			if (0 == m_Para.m_CovCType.compare("CovCRngR"))
			{
				ScansCovVoxelGrid();
			}
		}
		else
		{
			m_vHdlPts.clear();
			for (size_t i = 0; i < m_EKFHdl_ptr->size(); i++)
			{
				Eigen::Vector3f tmpPt;
				tmpPt(0) = m_EKFHdl_ptr->points[i].x;
				tmpPt(1) = m_EKFHdl_ptr->points[i].y;
				tmpPt(2) = m_EKFHdl_ptr->points[i].z;
				m_vHdlPts.emplace_back(tmpPt.cast<double>());
			}
		}
	}
	//----------------------------------------------------------------------
	//	
	//----------------------------------------------------------------------
	void ScansCovNeibK()
	{
		std::vector<int> vIdx;
		std::vector<float> vDist;
		m_vHdlPts.clear();
		for (size_t i = 0; i < m_EKFHdl_ptr->size(); i++)
		{
			m_KdHdlP_ptr->nearestKSearch(m_EKFHdl_ptr->points[i], m_Para.m_NebK, vIdx, vDist);
			Mat3d sCov = CalCov(m_InaHdl_ptr, vIdx);
			m_vHdlCov.emplace_back(sCov);
			Eigen::Vector3f tmpPt;
			tmpPt(0) = m_EKFHdl_ptr->points[i].x;
			tmpPt(1) = m_EKFHdl_ptr->points[i].y;
			tmpPt(2) = m_EKFHdl_ptr->points[i].z;
			m_vHdlPts.emplace_back(tmpPt.cast<double>());
		}
	}
	void ScansCovRange()
	{
		std::vector<int> vIdx;
		std::vector<float> vDist;
		m_vHdlPts.clear();
		for (size_t i = 0; i < m_EKFHdl_ptr->size(); i++)
		{
			m_KdHdlP_ptr->radiusSearch(m_EKFHdl_ptr->points[i], m_Para.m_RngR, vIdx, vDist);
			if (vIdx.size() < 3)
			{
				continue;
			}
			Mat3d sCov = CalCov(m_InaHdl_ptr, vIdx);
			m_vHdlCov.emplace_back(sCov);
			Eigen::Vector3f tmpPt;
			tmpPt(0) = m_EKFHdl_ptr->points[i].x;
			tmpPt(1) = m_EKFHdl_ptr->points[i].y;
			tmpPt(2) = m_EKFHdl_ptr->points[i].z;
			m_vHdlPts.emplace_back(tmpPt.cast<double>());
		}
	}
	void ScansCovVoxelGrid()//
	{
		std::vector<int> vIdx;
		std::vector<float> vDist;
		m_vHdlPts.clear();
		for (size_t i = 0; i < m_EKFHdl_ptr->size(); i++)
		{
			m_KdHdlP_ptr->radiusSearch(m_EKFHdl_ptr->points[i], m_Para.m_VoxS, vIdx, vDist);
			if (vIdx.size() < 3)
			{
				continue;
			}
			Mat3d sCov = CalCov(m_InaHdl_ptr, vIdx);
			m_vHdlCov.emplace_back(sCov);
			Eigen::Vector3f tmpPt;
			tmpPt(0) = m_EKFHdl_ptr->points[i].x;
			tmpPt(1) = m_EKFHdl_ptr->points[i].y;
			tmpPt(2) = m_EKFHdl_ptr->points[i].z;
			m_vHdlPts.emplace_back(tmpPt.cast<double>());
		}
	}
	//----------------------------------------------------------------------
	//	
	//----------------------------------------------------------------------
	bool CalDistAndJacH(const Mat4d& XbarK, std::vector<double>& vRawD, std::vector<Vec6d>& vRawH)
	{
		Mat3d Rk = XbarK.block<3, 3>(0, 0);
		Vec3d Tk = XbarK.block<3, 1>(0, 3);
		int nCnt = 0;
		for (int i = 0; i < m_vHdlPts.size(); i++)
		{
			Vec3d tmpS = m_vHdlPts[i];
			Vec3d tmpT = Rk * tmpS + Tk;
			pcl::PointXYZ TraPt;
			TraPt.x = tmpT(0);
			TraPt.y = tmpT(1);
			TraPt.z = tmpT(2);
			std::vector<int> vIdx;
			std::vector<float> vDist;
			m_KdMapP_ptr->nearestKSearch(TraPt, 1, vIdx, vDist);
			Vec3d tmpM = m_vMapPts[vIdx[0]];
			Vec6d tmpH;
			double tmpD = 0.0;
			if (0 == m_Para.m_DistType.compare("pt2pt"))
			{
				tmpD = DistPt2PtFun(XbarK, tmpS, tmpM, tmpH);			
			}
			else if (0 == m_Para.m_DistType.compare("pt2pl"))
			{
				Vec3d tmpN = m_vMapNor[vIdx[0]];
				tmpD = DistPt2PlFun(XbarK, tmpS, tmpM, tmpN, tmpH);
			}
			else if (0 == m_Para.m_DistType.compare("pt2d"))
			{
				Mat3d mCov = m_vMapCov[vIdx[0]];
				tmpD = DistPt2DFun(XbarK, tmpS, tmpM, mCov, tmpH);
			}
			else if (0 == m_Para.m_DistType.compare("d2d"))
			{
				Mat3d sCov = m_vHdlCov[i];
				Mat3d mCov = m_vMapCov[vIdx[0]];
				tmpD = DistD2DFun(XbarK, tmpS, tmpM, mCov, sCov, tmpH);
			}
			nCnt++;
			vRawD.emplace_back(tmpD);
			vRawH.emplace_back(tmpH);
		}
		return (nCnt > 20) ? true : false;
	}
	//-----------------------------------------------------------------------------------
	double DistPt2PtFun(const Mat4d& XbarK, const Vec3d& tmpS, const Vec3d& tmpM, Vec6d& tmpH)
	{
		Mat3d Rk = XbarK.block<3, 3>(0, 0);
		Vec3d Tk = XbarK.block<3, 1>(0, 3);
		Vec3d pp = Rk * tmpS + Tk - tmpM;
		double tmpD = std::sqrt(pp.transpose() * pp); //pp.norm();
		tmpD = tmpD < 1.0E-8 ? 1.0E-8 : tmpD;
		Vec3d tmp1 = ( - pp.transpose() * Rk * SkewD(tmpS)).transpose();
		tmpH << tmp1(0), tmp1(1), tmp1(2), pp(0), pp(1), pp(2);
		tmpH = (1.0 / tmpD) * tmpH;
		return tmpD;
	}
	double DistPt2PlFun(const Mat4d& XbarK, const Vec3d& tmpS, const Vec3d& tmpM, const Vec3d& tmpN, Vec6d& tmpH)
	{
		Mat3d Rk = XbarK.block<3, 3>(0, 0);
		Vec3d Tk = XbarK.block<3, 1>(0, 3);
		Vec3d pp = Rk * tmpS + Tk - tmpM;
		double tmpD = tmpN.transpose() * pp;
		Vec3d tmp1 = ( - tmpN.transpose() * Rk * SkewD(tmpS)).transpose();
		tmpH << tmp1(0), tmp1(1), tmp1(2), tmpN(0), tmpN(1), tmpN(2);
		return tmpD;
	}
	double DistPt2DFun(const Mat4d& XbarK, const Vec3d& tmpS, const Vec3d& tmpM, const Mat3d& mCov, Vec6d& tmpH)
	{
		Mat3d Rk = XbarK.block<3, 3>(0, 0);
		Vec3d Tk = XbarK.block<3, 1>(0, 3);
		Vec3d pp = Rk * tmpS + Tk - tmpM;
		Mat3d tmpCov = mCov.inverse();
		double tmpD = std::sqrt(pp.transpose() * tmpCov * pp);
		Vec3d tmp1 = (pp.transpose() * tmpCov).transpose();
		Vec3d tmp2 = tmp1.transpose() * (-Rk * SkewD(tmpS));
		tmpH << tmp2(0), tmp2(1), tmp2(2), tmp1(0), tmp1(1), tmp1(2);
		tmpD = tmpD < 1.0E-8 ? 1.0E-8 : tmpD;
		tmpH = (1.0 / tmpD) * tmpH;
		return tmpD;
	}
	double DistD2DFun(const Mat4d& XbarK, const Vec3d& tmpS, const Vec3d& tmpM, const Mat3d& mCov, const Mat3d& sCov, Vec6d& tmpH)
	{
		Mat3d Rk = XbarK.block<3, 3>(0, 0);
		Vec3d Tk = XbarK.block<3, 1>(0, 3);
		Vec3d pp = (Rk * tmpS + Tk) - tmpM;
		Mat3d tmpCov = (Rk * sCov * Rk.transpose() + mCov).inverse();
		double tmpD = std::sqrt(pp.transpose() * tmpCov * pp);
		Vec3d tmp1 = (pp.transpose() * tmpCov).transpose();
		Vec3d tmp2 = tmp1.transpose() * (-Rk * SkewD(tmpS) - Rk * sCov * tmpCov);
		tmpH << tmp2(0), tmp2(1), tmp2(2), tmp1(0), tmp1(1), tmp1(2);
		tmpD = tmpD < 1.0E-8 ? 1.0E-8 : tmpD;
		tmpH = (1.0 / tmpD) * tmpH;
		return tmpD;
	}
	//----------------------------------------------------------------------
	//	new vH, when robust loss function is used
	//----------------------------------------------------------------------
	std::vector<Vec6d> GeneHFun(const std::vector<double>& vRawD, const std::vector<double>& vW, const std::vector<Vec6d>& vRawH)
	{
		std::vector<Vec6d> vH = vRawH;
		size_t NumPts = vRawD.size();
		for (size_t i = 0; i < NumPts; i++)
		{
			double tmp = ((double)NumPts) * vRawD[i] * vW[i];
			vH[i] = tmp * vRawH[i];
		}
		return vH;
	}
	//----------------------------------------------------------------------
	//	the state is (R, t), which is also represented by (ax,ay,az,x,y,z)
	//----------------------------------------------------------------------
	void PropagationM(const Mat4d& CurImuT, const Mat4d& PreImuT,
		Mat6d& Fx, Mat6d& Gu, Mat4d& Xbar)
	{
		Mat4d DifTF = PreImuT.inverse() * CurImuT;
		Xbar = m_TFK_1 * DifTF;
		Mat3d dRk = DifTF.block<3, 3>(0, 0);
		Vec3d dTk = DifTF.block<3, 1>(0, 3);
		Mat3d Rk1 = m_TFK_1.block<3, 3>(0, 0);
		// 1: X=[R,t],SO(3) keep with 2020-06-02
		Fx.block<3, 3>(0, 0) = dRk.transpose();
		Fx.block<3, 3>(0, 3) = Mat3d::Zero();
		Fx.block<3, 3>(3, 0) = -Rk1 * SkewD(dTk);
		Fx.block<3, 3>(3, 3) = Mat3d::Identity();
		Gu.block<3, 3>(0, 0) = Mat3d::Identity();
		Gu.block<3, 3>(0, 3) = Mat3d::Zero();
		Gu.block<3, 3>(3, 0) = Mat3d::Zero();
		Gu.block<3, 3>(3, 3) = Rk1;
	}
	//----------------------------------------------------------------------
	//	the state is (R, t), which is also represented by (ax,ay,az,x,y,z)
	//----------------------------------------------------------------------
	void ObservationM(const Mat4d& XbarK, const Mat6d& CbarK)
	{
		std::vector<double> vRawD;
		std::vector<double> vD;
		std::vector<double> vW;
		std::vector<Vec6d> vRawH;
		std::vector<Vec6d> vH;

		m_StateK = CTF2State(XbarK);	// ax, ay, az, x, y, z
		m_CovK = CbarK;

		CalDistAndJacH(XbarK, vRawD, vRawH);
		vDistLossFun(vRawD, m_Para.m_LossName, vD, vW);
		vH = GeneHFun(vRawD, vW, vRawH);
		double Qk = m_Para.m_ScaleC * m_Para.m_ObsersCov;
		for (size_t i = 0; i < vD.size(); i++) 
		{
			Vec6d tmpH = vH[i];
			double Sk = tmpH.transpose() * m_CovK * tmpH + Qk;
			Vec6d Kk = (m_CovK * tmpH) / Sk;
			m_StateK = m_StateK + Kk * (0.0 - vD[i]);
			m_CovK = (Mat6d::Identity() - Kk * tmpH.transpose()) * m_CovK;
		}
		m_StateK(0) = warpToPi(m_StateK(0));
		m_StateK(1) = warpToPi(m_StateK(1));
		m_StateK(2) = warpToPi(m_StateK(2));
	}
	//----------------------------------------------------------------------
	//	fitness score is calculated to evaluate the performance.
	//----------------------------------------------------------------------
	float CalFitScorePP(float maxDist) {
		int nCnt = 0;
		for (int i = 0; i < m_FitHdl_ptr->points.size(); i++)
		{
			std::vector<int> vIdx;
			std::vector<float> vDist;
			pcl::PointXYZ pt_src = m_FitHdl_ptr->points[i];
			m_KdMapP_ptr->nearestKSearch(pt_src, 1, vIdx, vDist);
			int nIdx = vIdx[0];
			pcl::PointNormal refPt = m_MapPN_ptr->points[nIdx];
			float dx = pt_src.x - refPt.x;
			float dy = pt_src.y - refPt.y;
			float dz = pt_src.z - refPt.z;
			float nx = refPt.normal_x, ny = refPt.normal_y, nz = refPt.normal_z;
			float fDist_pl = abs(nx * dx + ny * dy + nz * dz);
			if (fDist_pl <= maxDist)
			{
				nCnt++;
			}
		}
		float ratio = nCnt / (double)m_FitHdl_ptr->points.size();
		return ratio;
	}
	//------------------------------------------------------------------------------------------------
	//
	//------------------------------------------------------------------------------------------------

	void InitViewer() {
		m_Viewer.setWindowName("3D Map Localization");
		m_Viewer.addCoordinateSystem(1);
		m_Viewer.setWindowBorders(true);
		m_Viewer.setSize(1000, 600);
		m_Viewer.setBackgroundColor(0.0, 0.0, 0.0);
		m_Viewer.setCameraPosition(0, 0, 100, 0, 0, 0);	//

		pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> InaColor(m_InaShow_ptr, 255, 0, 0);
		m_Viewer.addPointCloud<pcl::PointXYZ>(m_InaShow_ptr, InaColor, "Raw data");    //��ʾ���ƣ�����fildColorΪ��ɫ��ʾ
		m_Viewer.setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 2, "Raw data");

		pcl::visualization::PointCloudColorHandlerCustom<pcl::PointNormal> MapColor(m_MapShow_ptr, 190, 190, 190);
		m_Viewer.addPointCloud<pcl::PointNormal>(m_MapShow_ptr, MapColor, "Map data");
		m_Viewer.setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 2, "Map data");

		pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> Gene_Tra(m_TraShow_ptr, 255, 255, 0);
		m_Viewer.addPointCloud<pcl::PointXYZ>(m_TraShow_ptr, Gene_Tra, "EKF-Gene-Tra");
		m_Viewer.setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 2, "EKF-Gene-Tra");

		pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> Gps_Tra(m_GpsShow_ptr, 255, 0, 0);
		m_Viewer.addPointCloud<pcl::PointXYZ>(m_GpsShow_ptr, Gps_Tra, "Gps-Tra");
		m_Viewer.setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 2, "Gps-Tra");

		pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> Imu_Tra(m_ImuShow_ptr, 128, 128, 0);
		m_Viewer.addPointCloud<pcl::PointXYZ>(m_ImuShow_ptr, Imu_Tra, "Imu-Tra");
		m_Viewer.setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 2, "Imu-Tra");

		m_Viewer.addText(m_DisInfo, 20, 20, 18, 1.0, 1.0, 0.0, "Process information");
	}

	bool isViewStop() { return m_Viewer.wasStopped(); }

	void show() {
		Eigen::Matrix4f tmpTF = m_TFK.inverse().cast<float>();
		pcl::transformPointCloud(*m_MapPN_ptr, *m_MapShow_ptr, tmpTF);
		pcl::visualization::PointCloudColorHandlerCustom<pcl::PointNormal> MapColor(m_MapShow_ptr, 190, 190, 190);
		m_Viewer.updatePointCloud<pcl::PointNormal>(m_MapShow_ptr, MapColor, "Map data");

		m_InaShow_ptr = m_InaHdl_ptr;// DownRandom(m_InaHdl_ptr, 0.9);
		pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> InaColor(m_InaShow_ptr, 255, 0, 0);
		m_Viewer.updatePointCloud<pcl::PointXYZ>(m_InaShow_ptr, InaColor, "Raw data");    //��ʾ���ƣ�����fildColorΪ��ɫ��ʾ

		pcl::transformPointCloud(*m_OutTra_ptr, *m_TraShow_ptr, tmpTF);
		pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> Gene_Tra(m_TraShow_ptr, 255, 255, 0);
		m_Viewer.updatePointCloud<pcl::PointXYZ>(m_TraShow_ptr, Gene_Tra, "EKF-Gene-Tra");

		pcl::transformPointCloud(*m_pGpsPose, *m_GpsShow_ptr, tmpTF);
		pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> Grd_Tra(m_GpsShow_ptr, 255, 0, 0);
		m_Viewer.updatePointCloud<pcl::PointXYZ>(m_GpsShow_ptr, Grd_Tra, "Gps-Tra");

		Eigen::Matrix4f OrgTF = CPose2TF(m_vImuPose[0]).inverse().cast<float>();
		pcl::transformPointCloud(*m_pLocPose, *m_ImuShow_ptr, OrgTF);
		pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> Imu_Tra(m_ImuShow_ptr, 128, 128, 128);
		m_Viewer.updatePointCloud<pcl::PointXYZ>(m_ImuShow_ptr, Imu_Tra, "Imu-Tra");

		m_Viewer.updateText(m_DisInfo, 20, 20, 18, 1.0, 1.0, 0.0, "Process information");
		m_Viewer.spinOnce(10);
	}

	void SetDisInfo(const std::string& DispInfo) { m_DisInfo = DispInfo; }

	void SaveViewer(const int& nFrm, const std::string& ImgFolder) {
		char FileName[100] = " ";
		sprintf_s(FileName, "%sLocImage%06d.png", ImgFolder.c_str(), nFrm);
		m_Viewer.saveScreenshot(std::string(FileName));
	}
	//
	void saveGpsImuPose(const Vec6d& CurImu, const Vec6d& CurGps)
	{
		pcl::PointXYZ tmpPt;
		tmpPt.x = CurGps(0);
		tmpPt.y = CurGps(1);
		tmpPt.z = CurGps(2);
		m_pGpsPose->points.push_back(tmpPt);
		tmpPt.x = CurImu(0);
		tmpPt.y = CurImu(1);
		tmpPt.z = CurImu(2);
		m_pLocPose->points.push_back(tmpPt);
	}
	//----------------------------------------------------------------------
	//	process
	//----------------------------------------------------------------------
	void ProcessNew()		//const Vec6d& CurImu
	{
		clock_t sss, aaa, bbb, ccc;
		size_t FrmLen = m_Para.m_vImuPose.size();
		std::vector<int> vTime;
		std::vector<int> vCovTime;
		std::ofstream LocLog;
		char FileName[200] = "\0";
		sprintf_s(FileName, "%s\\Time.txt", m_LogDir.c_str());
		LocLog.open(FileName);
		LocLog << "nFrm  ReadT  ProcessT"<< std::endl;

		for (m_nFrm = m_Para.m_StartID; m_nFrm < FrmLen; m_nFrm++)
		{
			int SelIdx = m_Para.m_vSelIdx[m_nFrm];
			sss = clock();
			load(SelIdx);
			aaa = clock();					
			vCovTime.push_back(aaa-sss);

			Mat6d Fx = Mat6d::Identity();
			Mat6d Gu = Mat6d::Zero();
			Mat4d XbarK = Mat4d::Identity();
			Mat6d CbarK = Mat6d::Identity();
			Vec6d CurImu = m_Para.m_vImuPose[m_nFrm];
			Vec6d CurGps = m_Para.m_vGrdPose[m_nFrm];

			if (m_Para.m_StartID == m_nFrm)	// the first step
			{
				XbarK = m_TFK_1 * m_Para.m_CalTF;
			}
			else
			{				
				Vec6d PreImu = m_vImuPose.back();
				Mat4d CurLidTF = CPose2TF(CurImu) * m_Para.m_CalTF;
				Mat4d PreLidTF = CPose2TF(PreImu) * m_Para.m_CalTF;
				PropagationM(CurLidTF, PreLidTF, Fx, Gu, XbarK);
			}
			CbarK = Fx * m_CovK_1 * Fx.transpose() + Gu * m_Mk * Gu.transpose();

			ObservationM(XbarK, CbarK);
			m_TFK = CState2TF(m_StateK);
			m_TFK_1 = m_TFK;
			m_CovK_1 = m_CovK;

			// convert to vehicle coordinate system
			Mat4d CurLocTF = m_TFK * m_Para.m_CalTF.inverse();
			m_PoseK = CTF2Pose(CurLocTF);
			m_vLocPose.push_back(m_PoseK);
			m_vImuPose.push_back(CurImu);
			//
			//Vec6d dErr = CurGps - m_PoseK;
			//double dD = std::sqrt(dErr(0) * dErr(0) + dErr(1) * dErr(1)+ dErr(2) * dErr(2));
			double dD = SEdistT(CurGps, m_PoseK);
			if (dD > 100)
			{
				break;
			}
			//
			bbb = clock();
			//pcl::transformPointCloud(*m_InaHdl_ptr, *m_FitHdl_ptr, m_TFK.cast<float>());
			m_FitScore = 0.5;// CalFitScorePP(0.5);
			ccc = clock();

			char DisplayInfo[200] = " ";
			sprintf_s(DisplayInfo, "Frm(%05d), Scalar(%f), DistType(%s), RobustF(%s), Read:%3dms, FitT:%3dms, ProcessT:%4dms, FitScore: %.04f, DistE: %.4f", m_nFrm, m_Para.m_ScaleC, m_Para.m_DistType.c_str(), m_Para.m_LossName.c_str(), aaa - sss, ccc - bbb, bbb - aaa, m_FitScore, dD);
			printf("%s\n", DisplayInfo);
			clear();
			vTime.push_back(ccc - aaa);
			LocLog << m_nFrm << " " << aaa-sss << " " << ccc - aaa <<  std::endl;
		}
		std::cout << "The length of m_vLocPose is :  " << m_vLocPose.size() << std::endl;
		char LocFile[200] = "\0";
		sprintf_s(LocFile, "%s\\LocLog.txt", m_LogDir.c_str());
		SaveVec6dPose(LocFile, m_vLocPose);
		double sum = std::accumulate(vTime.begin(), vTime.end(), (double)0.0f); // 
		double aveT = sum / ((double)vTime.size());
		double sumR = std::accumulate(vCovTime.begin(), vCovTime.end(), (double)0.0f); // 
		double aveRT = sumR / ((double)vCovTime.size());
		LocLog << m_nFrm << " " << aveRT << " " << aveT << std::endl;
		LocLog.close();
	}
	//----------------------------------------------------------------------
	//	process
	//----------------------------------------------------------------------
	void ProcessShow()		//const Vec6d& CurImu
	{
		clock_t sss, aaa, bbb, ccc;
		size_t FrmLen = m_Para.m_vImuPose.size();
		std::vector<int> vTime;
		std::vector<int> vCovTime;
		std::ofstream LocLog;
		char FileName[200] = "\0";
		sprintf_s(FileName, "%s\\Time.txt", m_LogDir.c_str());
		LocLog.open(FileName);
		LocLog << "nFrm  ReadT  ProcessT" << std::endl;
		m_nFrm = m_Para.m_StartID;

		while (true) {
			if (m_nFrm == FrmLen) { break; }
			int SelIdx = m_Para.m_vSelIdx[m_nFrm];
			sss = clock();
			load(SelIdx);
			aaa = clock();
			Vec6d CurImu = m_Para.m_vImuPose[m_nFrm];
			Vec6d CurGps = m_Para.m_vGrdPose[m_nFrm];
			saveGpsImuPose(CurImu, CurGps);

			Mat6d Fx = Mat6d::Identity();
			Mat6d Gu = Mat6d::Zero();
			Mat4d XbarK = Mat4d::Identity();
			Mat6d CbarK = Mat6d::Identity();
			if (m_Para.m_StartID == m_nFrm)	// the first step
			{
				XbarK = m_TFK_1;
			}
			else
			{
				Vec6d PreImu = m_vImuPose.back();
				Mat4d CurImuTF = CPose2TF(CurImu);
				Mat4d PreImuTF = CPose2TF(PreImu);
				PropagationM(CurImuTF, PreImuTF, Fx, Gu, XbarK);
			}
			CbarK = Fx * m_CovK_1 * Fx.transpose() + Gu * m_Mk * Gu.transpose();

			ObservationM(XbarK, CbarK);
			m_TFK = CState2TF(m_StateK);
			m_TFK_1 = m_TFK;
			m_CovK_1 = m_CovK;
			m_PoseK = CState2Pose(m_StateK);

			m_vLocPose.push_back(m_PoseK);
			m_vImuPose.push_back(CurImu);
			//
			double dD = SEdistT(CurGps, m_PoseK);
			if (dD > 100)
			{
				break;
			}
			//
			bbb = clock();
			//pcl::transformPointCloud(*m_InaHdl_ptr, *m_FitHdl_ptr, m_TFK.cast<float>());
			m_FitScore = 0.5;// CalFitScorePP(0.5);
			ccc = clock();

			char DisplayInfo[200] = " ";
			sprintf_s(DisplayInfo, "Frm(%05d), Scalar(%f), DistType(%s), RobustF(%s), Read:%3dms, FitT:%3dms, ProcessT:%4dms, FitScore: %.04f, DistE: %.4f", m_nFrm, m_Para.m_ScaleC, m_Para.m_DistType.c_str(), m_Para.m_LossName.c_str(), aaa - sss, ccc - bbb, bbb - aaa, m_FitScore, dD);
			printf("%s\n", DisplayInfo);

			SetDisInfo(DisplayInfo);
			show();

			clear();
			++m_nFrm;
		}
		std::cout << "The length of m_vLocPose is :  " << m_vLocPose.size() << std::endl;
		char LocFile[200] = "\0";
		sprintf_s(LocFile, "%s\\LocLog.txt", m_LogDir.c_str());
		SaveVec6dPose(LocFile, m_vLocPose);
		double sum = std::accumulate(vTime.begin(), vTime.end(), (double)0.0f); // 
		double aveT = sum / ((double)vTime.size());
		double sumR = std::accumulate(vCovTime.begin(), vCovTime.end(), (double)0.0f); // 
		double aveRT = sumR / ((double)vCovTime.size());
		LocLog << m_nFrm << " " << aveRT << " " << aveT << std::endl;
		LocLog.close();
	}
};

#endif


