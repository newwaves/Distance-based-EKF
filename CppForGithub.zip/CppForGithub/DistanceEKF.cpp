﻿// DistanceEKF.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include <iostream>
#include "LocComFun.h"
#include "LocParams.h"
#include "DistanceEKF.h"
#include "RobustDist.h"


int main()
{
	clock_t time_stt = clock(); // ��ʱ
	CDistanceEKF myLoc;

	//myLoc.ProcessShow();
	
	myLoc.ProcessNew();
	
	return 0;
}