#pragma once
#ifndef H_LOCPARAMS_H
#define H_LOCPARAMS_H

#include "LocComFun.h"

#include <iostream>
#include <istream>
#include <vector>
#include <iosfwd>
#include <string>

//************************************************************************
//
//************************************************************************
class CLocPara
{
private:

public:
	std::string m_DataSets;		// dataset name
	std::string m_DistType;		// pt2pt, pt2pl, pt2d, d2d
	std::string m_CovCType;		// nebK-search, radi-search, or voxelgrid-search
	std::string m_LossName;		// robust loss function name, e.g. Huber, Tukey, etc.
	Mat4d   m_CalTF;			// Calibration TF (LiDAR and IMU)

	double	m_MinR;
	double	m_MaxR;

	int		m_NebK;
	double	m_RngR;
	double	m_VoxS;

	double	m_ScaleC;
	double	m_ObsersCov;	//	a scalar, distance as measurement of filter
	Vec6d	m_MotionCov;	//	[ax,ay,az, x, y, z] defined as [R,t]
	Vec6d   m_InitCov;

	std::vector<Vec6d>	m_vGrdPose;	//	x y z az ay ax
	std::vector<Vec6d>	m_vImuPose;	//
	std::vector<int>	m_vIdx;
	std::vector<int>	m_vSelIdx;
	int   m_StartID;	// From 1->end
	Mat4d m_StartTF;

	std::string m_MapRoot;
	std::string m_HdlRoot;
	std::string m_MapName;

	void clear()
	{
		m_vGrdPose.clear();
		m_vImuPose.clear();
		m_vIdx.clear();
		m_vSelIdx.clear();
	}
	void init()
	{
		m_StartTF = CPose2TF(m_vGrdPose[m_StartID]); // m_StartID
	}

	//---------------------------------------------
	CLocPara()
	{
		read();
		init();
		show();
	}
	~CLocPara()
	{}

	//---------------------------------------------------------------------
	//  All parameter load are plotted on screen.
	//---------------------------------------------------------------------
	void show()
	{
		std::cout << "The patameters of Distance-based EKF are load. " << std::endl;
		std::cout << "---------------------------------------------------------------------------------" << std::endl;
		std::cout << "   m_StartID        : " << m_StartID << std::endl;
		//std::cout << "   m_StartTF        : " << CTF2Pose(m_StartTF).transpose() << std::endl;
		std::cout << "   m_DataSets       : " << m_DataSets << std::endl;
		std::cout << "   m_DistType       : " << m_DistType << std::endl;
		std::cout << "   m_CovCType       : " << m_CovCType << std::endl;
		std::cout << "   m_LossName       : " << m_LossName << std::endl;
		std::cout << "   m_MinR           : " << m_MinR << std::endl;
		std::cout << "   m_MaxR           : " << m_MaxR << std::endl;

		//std::cout << "   m_CalTF          : " << "\n" << m_CalTF << std::endl;

		std::cout << "   m_ObsersCov      : " << m_ObsersCov << std::endl;
		std::cout << "   m_MotionCov      : " << m_MotionCov.transpose() << std::endl;
		std::cout << "   m_InitCov        : " << m_InitCov.transpose() << std::endl;

		std::cout << "   m_vGrdPose       : " << m_vGrdPose.size() << std::endl;
		std::cout << "   m_vImuPose       : " << m_vImuPose.size() << std::endl;
		std::cout << "   m_vIdx           : " << m_vIdx.size() << std::endl;
		std::cout << "   m_vSelIdx        : " << m_vSelIdx.size() << std::endl;

		std::cout << "   m_MapRoot        : " << m_MapRoot << std::endl;
		std::cout << "   m_MapFile        : " << m_MapName << std::endl;
		std::cout << "   m_HdlRoot        : " << m_HdlRoot << std::endl;
		std::cout << "---------------------------------------------------------------------------------" << std::endl;
	}
	//---------------------------------------------------------------------
	//  The parameters of DistEKF are load.
	//---------------------------------------------------------------------
	void read()
	{
		std::string ParaFile = "DistEKFPara.txt";
		std::ifstream ifData;
		ifData.open(ParaFile);
		if (!ifData)
		{
			cout << "Cannot get the DistEKFPara.txt file!" << endl;
			exit(-1);
		}
		std::stringstream ss;
		std::string tmpStr;
		clear();
		while (!ifData.eof())
		{
			getline(ifData, tmpStr);
			if (tmpStr.empty())
			{
				continue;
			}
			if (tmpStr[0] == '#')
			{
				continue;
			}
			ss.clear();
			ss.str(tmpStr);
			std::string sHeader;
			ss >> sHeader; // 
			if (0 == sHeader.compare("ExpDataSet"))
			{
				ss >> m_DataSets;
				continue;
			}
			if (0 == sHeader.compare("RobustLossName"))
			{
				ss >> m_LossName;
				continue;
			}
			if (0 == sHeader.compare("HdlRoot"))
			{
				std::string tmp1, tmp2;
				ss >> tmp1 >> tmp2;
				m_HdlRoot = tmp1 + ' ' + tmp2;
				continue;
			}
			if (0 == sHeader.compare("MapRoot"))
			{
				std::string tmp1, tmp2;
				ss >> tmp1 >> tmp2;
				m_MapRoot = tmp1 + ' ' + tmp2;
				continue;
			}
			if (0 == sHeader.compare("MapName"))
			{
				ss >> m_MapName;
				continue;
			}
			if (0 == sHeader.compare("CalibrationTF"))
			{
				std::vector<double> vTmpTQ;
				vTmpTQ.resize(7, 0.0); // tx ,ty , tz , qx , qy , qz , qw
				ss >> vTmpTQ[0] >> vTmpTQ[1] >> vTmpTQ[2] >> vTmpTQ[3] >> vTmpTQ[4] >> vTmpTQ[5] >> vTmpTQ[6];
				m_CalTF = CTQ2TF(vTmpTQ);
				continue;
			}
			if (0 == sHeader.compare("MotionCov"))
			{
				for (int i = 0; i < 6; i++)
				{
					ss >> m_MotionCov(i);
				}
				continue;
			}
			if (0 == sHeader.compare("ObsersCov"))//ScaleC
			{
				ss >> m_ObsersCov;
				continue;
			}
			if (0 == sHeader.compare("ScaleC"))//ScaleC
			{
				ss >> m_ScaleC;
				continue;
			}
			if (0 == sHeader.compare("InitCov"))
			{
				for (int i = 0; i < 6; i++)
				{
					ss >> m_InitCov[i];
				}
				continue;
			}
			if (0 == sHeader.compare("StartID")) 
			{
				ss >> m_StartID;
				m_StartID = m_StartID - 1; // 2020-11-28
				continue;
			} 
			if (0 == sHeader.compare("CovCType"))
			{
				ss >> m_CovCType; // CovCNebK  CovCRngR  CovCNdtS(VoxelGrid)
				continue;
			}
			if (0 == sHeader.compare("NeihborK")) 
			{
				ss >> m_NebK;
				continue;
			}
			if (0 == sHeader.compare("RangeRadius")) 
			{
				ss >> m_RngR;
				continue;
			}
			if (0 == sHeader.compare("VoxeGridSize")) 
			{
				ss >> m_VoxS;
				continue;
			}
			if (0 == sHeader.compare("DistType"))
			{
				ss >> m_DistType;
				continue;
			}//
			if (0 == sHeader.compare("LidarRange"))
			{
				ss >> m_MinR >> m_MaxR;
				continue;
			}
			if (0 == sHeader.compare("LocPoses"))
			{
				Vec6d GrdPose;
				Vec6d ImuPose;
				int tmpIdx;
				int tmpSel;
				ss >> tmpIdx >> tmpSel;
				for (int i = 0; i < 6; i++)
				{
					ss >> GrdPose(i);
				}
				for (int i = 0; i < 6; i++)
				{
					ss >> ImuPose(i);
				}
				m_vGrdPose.push_back(GrdPose);//m_vGrdPose
				m_vImuPose.push_back(ImuPose);
				m_vIdx.push_back(tmpIdx);
				m_vSelIdx.push_back(tmpSel);
			}
		}
	}

};




#endif
