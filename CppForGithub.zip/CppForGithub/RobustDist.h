#pragma once
#ifndef H_ROBUST_DIST_H
#define H_ROBUST_DIST_H

#include "LocComFun.h"

//----------------------------------------------------------------------------
inline
void LossL2Fun(const std::vector<double> & vInaD, std::vector<double> &vOutD, 
	std::vector<double> & vOutW)
{
	vOutD.clear();
	vOutW.clear();
	for (size_t i = 0; i < vInaD.size(); i++)
	{
		double tmpR = vInaD[i];				//	raw distance
		double tmpD = 0.5 * tmpR * tmpR;	//	new distance
		double tmpW = 1.0;					//	weights
		vOutD.push_back(tmpD);
		vOutW.push_back(tmpW);
	}
}
//----------------------------------------------------------------------------
inline
void LossL1Fun(const std::vector<double>& vInaD, std::vector<double>& vOutD,
	std::vector<double>& vOutW)
{
	vOutD.clear();
	vOutW.clear();
	for (size_t i = 0; i < vInaD.size(); i++)
	{
		double tmpR = vInaD[i];
		double tmpD = std::abs(tmpR);
		if (tmpD < 1.0E-8)
		{
			tmpD = 1.0E-8;
		}
		double tmpW = 1.0 / tmpD;
		vOutD.push_back(tmpD);
		vOutW.push_back(tmpW);
	}
}
//----------------------------------------------------------------------------
inline
void LossL1_L2Fun(const std::vector<double>& vInaD, std::vector<double>& vOutD,
	std::vector<double>& vOutW)
{
	vOutD.clear();
	vOutW.clear();
	for (size_t i = 0; i < vInaD.size(); i++)
	{
		double tmpR = vInaD[i];
		double tmp1 = std::sqrt(1 + 0.5 * tmpR * tmpR);
		double tmpD = 2.0 * (tmp1 - 1.0);
		if (tmp1 < 1.0E-8)
		{
			tmp1 = 1.0E-8;
		}
		double tmpW = 1.0 / tmp1;
		vOutD.push_back(tmpD);
		vOutW.push_back(tmpW);
	}
}
//----------------------------------------------------------------------------
inline
void LossLpFun(const std::vector<double>& vInaD, const double p, std::vector<double>& vOutD,
	std::vector<double>& vOutW)
{
	vOutD.clear();
	vOutW.clear();
	for (size_t i = 0; i < vInaD.size(); i++)
	{
		double tmpR = vInaD[i];
		double tmpD = std::pow(std::abs(tmpR), p) / p;
		double tmpW = std::pow(std::abs(tmpR), (p - 2));
		vOutD.push_back(tmpD);
		vOutW.push_back(tmpW);
	}
}
//----------------------------------------------------------------------------
inline
void LossFairFun(const std::vector<double>& vInaD, const double FairC, std::vector<double>& vOutD,
	std::vector<double>& vOutW)
{
	vOutD.clear();
	vOutW.clear();
	double FairC2 = FairC * FairC;
	for (size_t i = 0; i < vInaD.size(); i++)
	{
		double tmpR = vInaD[i];
		double tmp1 = std::abs(tmpR) / FairC;
		double tmpD = FairC2 * (tmp1 - std::log(1.0 + tmp1));
		double tmpW = 1.0 / (1.0 + tmp1);
		vOutD.push_back(tmpD);
		vOutW.push_back(tmpW);
	}
}
//----------------------------------------------------------------------------
inline
void LossHuberFun(const std::vector<double>& vInaD, const double HuberK, std::vector<double>& vOutD,
	std::vector<double>& vOutW)
{
	vOutD.clear();
	vOutW.clear();
	for (size_t i = 0; i < vInaD.size(); i++)
	{
		double tmpR = vInaD[i];
		double tmp1 = std::abs(tmpR);
		double tmpD = 0.0;
		double tmpW = 0.0;
		if (tmp1 < HuberK)
		{
			tmpD = 0.5 * tmpR * tmpR;
			tmpW = 1.0;
		}
		else
		{
			tmpD = HuberK * (tmp1 - 0.5 * HuberK);
			tmp1 = (tmp1 < 1.0E-8) ? 1.0E-8 : tmp1;
			tmpW = HuberK / tmp1;
		}
		vOutD.push_back(tmpD);
		vOutW.push_back(tmpW);
	}
}
//----------------------------------------------------------------------------
inline
void LossCauchyFun(const std::vector<double>& vInaD, const double CauchyC, std::vector<double>& vOutD,
	std::vector<double>& vOutW)
{
	vOutD.clear();
	vOutW.clear();
	//double CauchyC2 = 0.5 * CauchyC; // the previous version
	double CauchyC2 = 0.5 * CauchyC * CauchyC;	// the lastest version, modified by Tao, 2023-06-27
	for (size_t i = 0; i < vInaD.size(); i++)
	{
		double tmpR = vInaD[i];
		double tmp1 = std::pow(tmpR / CauchyC, 2.0);
		double tmpD = CauchyC2 * std::log(1.0 + tmp1);
		double tmpW = 1.0 / (1.0 + tmp1);
		vOutD.push_back(tmpD);
		vOutW.push_back(tmpW);
	}
}
//----------------------------------------------------------------------------
inline
void LossGeman_McClureFun(const std::vector<double>& vInaD, std::vector<double>& vOutD,
	std::vector<double>& vOutW)
{
	vOutD.clear();
	vOutW.clear();
	for (size_t i = 0; i < vInaD.size(); i++)
	{
		double tmpR = vInaD[i];
		double tmp1 = tmpR * tmpR;
		double tmpD = tmp1 / (1.0 + tmp1);
		double tmpW = 1.0 / std::pow((1.0 + tmp1), 2.0);
		vOutD.push_back(tmpD);
		vOutW.push_back(tmpW);
	}
}
//----------------------------------------------------------------------------
inline
void LossWelschFun(const std::vector<double>& vInaD, const double& WelschC, std::vector<double>& vOutD,
	std::vector<double>& vOutW)
{
	vOutD.clear();
	vOutW.clear();
	double WelschC2 = 0.5 * WelschC * WelschC;
	for (size_t i = 0; i < vInaD.size(); i++)
	{
		double tmpR = vInaD[i];
		double tmp1 = std::exp( - std::pow(tmpR / WelschC, 2.0));
		double tmpD = WelschC2 * (1.0 - tmp1);
		double tmpW = tmp1;
		vOutD.push_back(tmpD);
		vOutW.push_back(tmpW);
	}
}
//----------------------------------------------------------------------------
inline
void LossTukeyFun(const std::vector<double>& vInaD, const double& TukeyC, std::vector<double>& vOutD,
	std::vector<double>& vOutW)
{
	vOutD.clear();
	vOutW.clear();
	double TukeyC2 = std::pow(TukeyC, 2.0) / 6.0;
	for (size_t i = 0; i < vInaD.size(); i++)
	{
		double tmpR = vInaD[i];
		double tmp1 = std::abs(tmpR);
		double tmpD = 0.0;
		double tmpW = 0.0;
		if (tmp1 < TukeyC)
		{
			double tmp2 = 1.0 - std::pow(tmpR / TukeyC, 2.0);
			tmpD = TukeyC2 * (1.0 - std::pow(tmp2, 3.0));
			tmpW = std::pow(tmp2, 2.0);
		}
		else
		{
			tmpD = TukeyC2;
			tmpW = 0.0;
		}
		vOutD.push_back(tmpD);
		vOutW.push_back(tmpW);
	}
}
inline
void FindMaxMinV(const std::vector<double>& vData, double& maxV, double& minV)
{
	maxV = -1e-6;
	minV = 1e6;
	for (size_t i = 0; i < vData.size(); i++)
	{
		if (vData[i] > maxV)
		{
			maxV = vData[i];
		}
		if (vData[i] < minV)
		{
			minV = vData[i];
		}
	}
}
//----------------------------------------------------------------------------
std::vector<double> vNormalizeW(const std::vector<double>& vW)
{
	std::vector<double> vOutW;
	if (vW.size() < 10)
	{
		exit(-1);
	}
	double maxV = 0.0;
	double minV = 0.0;
	FindMaxMinV(vW, maxV, minV);
	double DmmV = maxV - minV;
	double tSum = 0.0;
	if (maxV != minV)
	{
		for (size_t i = 0; i < vW.size(); i++)
		{
			double tmp = (vW[i] - minV) / DmmV;
			vOutW.push_back(tmp);
			tSum = tSum + tmp;
		}
	}
	else
	{
		vOutW = vW;
		tSum = maxV * vW.size();
	}
	double tmp2 = 1.0 / tSum;
	for (size_t i = 0; i < vW.size(); i++)
	{
		vOutW[i] = tmp2 * vOutW[i];
	}
	return vOutW;
}
//----------------------------------------------------------------------------
inline
void vDistLossFun(const std::vector<double>& vRawD, const std::string& FunName,
	std::vector<double>& vNewD, std::vector<double>& vW)
{//"L2" "L1" "L1-L2" "Lp" "Tukey" "Welsch" "Huber" "Cauchy" "Fair" "Geman_McClure"
	std::vector<double> vOutW;
	if (0 == FunName.compare("L2"))
	{
		LossL2Fun(vRawD, vNewD, vOutW);
	}
	else if (0 == FunName.compare("L1"))
	{
		LossL1Fun(vRawD, vNewD, vOutW);
	}
	else if (0 == FunName.compare("L1_L2"))
	{
		LossL1_L2Fun(vRawD, vNewD, vOutW);
	}
	else if (0 == FunName.compare("Lp"))
	{
		double p = 0.5;
		LossLpFun(vRawD, p, vNewD, vOutW);
	}
	else if (0 == FunName.compare("Tukey"))
	{
		double TukeyC = 2.5;
		LossTukeyFun(vRawD, TukeyC, vNewD, vOutW);
	}
	else if (0 == FunName.compare("Welsch"))
	{
		double WelschC = 1.5;
		LossWelschFun(vRawD, WelschC, vNewD, vOutW);
	}
	else if (0 == FunName.compare("Huber"))
	{
		double HuberK = 0.75;
		LossHuberFun(vRawD, HuberK, vNewD, vOutW);
	}
	else if (0 == FunName.compare("Cauchy"))
	{
		double CauchyC = 0.75; // 0.8-1.0 2023-06-27
		LossCauchyFun(vRawD, CauchyC, vNewD, vOutW);
	}
	else if (0 == FunName.compare("Fair"))
	{
		double FairC = 2;
		LossFairFun(vRawD, FairC, vNewD, vOutW);
	}
	else if (0 == FunName.compare("Geman_McClure"))
	{
		LossGeman_McClureFun(vRawD, vNewD, vOutW);
	}
	else
	{
		vNewD = vRawD;
		for (size_t i = 0; i < vRawD.size(); i++)
		{
			vOutW.push_back(1.0);
		}
	}
	vW = vNormalizeW(vOutW);
}

//----------------------------------------------------------------------------
#endif