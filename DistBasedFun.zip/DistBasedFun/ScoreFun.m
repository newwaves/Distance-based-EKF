function Score = ScoreFun(kdMap, ptMap, ptOrg, tmpTF)

% % trTF = ParaS.CorresTF * ParaS.CalibTF;  % 2020-12-04 version 1
trTF = tmpTF;
[vTraPts, vHdlPts, vMapPts, vMapNor] = FindCorrespondences(kdMap, ptMap, ptOrg, trTF, 1, 10);

%%
vDPts = vTraPts - vMapPts;
if ~isempty(vMapNor)
    tmpNN = sqrt(vMapNor(:,1).^2 + vMapNor(:,2).^2 + vMapNor(:,3).^2);
    tmpIxd = tmpNN > 10e-6;
    tmpNN = tmpNN(tmpIxd);
    OrgP2PL = sum(vDPts(tmpIxd,:) .* vMapNor(tmpIxd,:), 2) ./ tmpNN;
    tmpP2PL = abs(OrgP2PL);
    tmpP2P = sqrt(vDPts(tmpIxd,1).^2 + vDPts(tmpIxd,2).^2 + vDPts(tmpIxd,3).^2);
else
    tmpP2P = sqrt(vDPts(:,1).^2 + vDPts(:,2).^2 + vDPts(:,3).^2);
    tmpP2PL = tmpP2P;
end

vDist = [tmpP2P, tmpP2PL];
%--------------------------------------------------------------------------
% vttmp = var(tmpP2PL);       % 2020-09-20
% vCov = [vttmp, vttmp, vttmp]; % 2020-09-20
Score = [ sum(vDist(:,1) < 0.5)/ ptOrg.Count, sum(vDist(:,2) < 0.5)/ ptOrg.Count];

end