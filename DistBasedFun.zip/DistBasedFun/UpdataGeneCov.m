function [Xk, Ck] = UpdataGeneCov(PtsCovArg, ptHdl, Xbk, Cbk, XbkTF, ParaS)
coresTF = ParaS.CorresTF;
[~, vHdlPts, vMapPts, vMapCov, vHdlCov] = FindCorrespondencesPtsCov(PtsCovArg, ptHdl, coresTF, 1, 100, ParaS);
%%
NumPts = size(vHdlPts, 1);
if NumPts > 20
    vH = zeros(size(vHdlPts, 1), 6);
    vRawD = zeros(size(vHdlPts, 1), 1);
    R = XbkTF(1:3, 1:3); % [t R] -> [x,y,z,az,ay,ax]
    T = XbkTF(1:3, end);
    for n = 1 : 1 : size(vHdlPts, 1)        
        tmpM = vMapPts(n, :)';      mCov = vMapCov(:, :, n); 
        tmpS = vHdlPts(n, :)';      sCov = vHdlCov(:, :, n);
               
        if isfield(ParaS, 'DistType') % DistType = {'D2D1', 'D2D2', 'P2D1', 'P2D2'};
            DistClass = ParaS.DistType;
        else
            DistClass = 'P2D1';    % default
        end        
        % In general, the models are expended.
        if strcmp(DistClass, 'P2D1')
            pp = R * tmpS + T - tmpM;
            TmpCov = eye(3) / mCov; % inv(mCov) in world coordinate
            d = sqrt((pp)' * TmpCov * pp); % 
            if d < 10e-8
                d = 10e-8;
            end
            H = (1 ./ d) .* pp' * TmpCov * [-R * skew(tmpS), eye(3)]; % 2022-03-23
        end
        %
        if strcmp(DistClass, 'D2D1A')
            pp = R * tmpS + T - tmpM;
            TmpCov = eye(3) / (R * sCov * R' + mCov);
            d = sqrt((pp)' * TmpCov * pp); % 
            if d < 10e-8
                d = 10e-8;
            end
            H = (1 ./ d) .* pp' * TmpCov * [-R * skew(tmpS) - ( R * sCov * TmpCov), eye(3)]; % D2D1A  our successful
        end
        %
        vH(n, :) = H;  % vH(n, :) = - F .* H;
        vRawD(n, :) = d;
    end  
    %----------------------------------------------------------
    if ParaS.isRobustLoss == 1        % Normalized 2021-08-24
        [vD, ~, vW] = vDistLossFun(vRawD, ParaS.RobustF);
        vW = vW ./ sum(vW);
        vF =  NumPts .* vRawD .* vW;   % weight function = influence function / x;
        vH =  vF .* vH;
    else
        vD = vRawD;
    end
    %----------------------------------------------------------  
    % Xbk - % [x,y,z,az,ay,ax] convert to [ax,ay,az, x, y, z]' -  [R, t]
    tmpXb = [Xbk(6);Xbk(5);Xbk(4);Xbk(1:3)]; % [ax,ay,az, x, y, z]' !!!!!
    % tmpTF = XbkTF;
    %%
    Qk = ParaS.ScaleC .* ParaS.QCov; %% modified @Home,2021-10-18
    %%
    for i = 1 : 1 : size(vD,1)  % X = [R,t]
        Sk = vH(i,:) * Cbk * vH(i,:)' + Qk;
        Kk = Cbk * vH(i,:)' / Sk;
        tmpXb = tmpXb + Kk * ( 0 - vD(i,:)'); % oPlus more robust!
        Cbk = (eye(6) - Kk * vH(i,:)) * Cbk;
    end
    %-----------------------------------------------------
    Xk = [tmpXb(4:6); wrapToPi(tmpXb(3)); wrapToPi(tmpXb(2)); wrapToPi(tmpXb(1))];% convert to [x,y,z,az,ay,ax]'
    Ck = Cbk;
    %-----------------------------------------------------
else
    Xk = Xbk;
    Ck = Cbk;
end
end
