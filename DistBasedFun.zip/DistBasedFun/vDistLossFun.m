function [f, H, W] = vDistLossFun(x, str, params)
if nargin < 3
    params.FairC = 2;% Fair
    params.CauchyC = 0.75;%1.25;
    params.WelschC = 1.5; %4.01;
    params.TukeyC = 2.5; % 5.0; - 2022-09-16 %  %5.6;
    
    params.HuberK = 0.75; %0.4;
    params.p = 0.5;%1.25;
end
if nargin < 2
    params.FairC = 0.9;% Fair
    params.CauchyC = 1.25;
    params.WelschC = 4.01;
    params.TukeyC = 5.6;
    params.HuberK = 2;
    params.p = 0.5;
    str = 'L2';
end
%
if strcmp(str, 'L2')
    f = 0.5 .* (x .^ 2);
    H = x;
    W = ones(length(x),1);
end
%
if strcmp(str, 'L1')
    f = abs(x);
    H = sign(x);
    W = 1 ./ abs(x);
end
%
if strcmp(str, 'L1-L2')
%     f = 2 .* (sqrt(1 + 0.5 .* (x .^ 2)) - 1);
%     H = x ./ (sqrt(1 + 0.5 .* (x .^ 2)));
%     W = 1 ./ (sqrt(1 + 0.5 .* (x .^ 2)));
    tmp1 = sqrt(1 + 0.5 .* (x .^ 2));
    f = 2 .* (tmp1 - 1);
    W = 1 ./ tmp1;
    H = x .* W;
    
end
%
if strcmp(str, 'Lp')
    p = params.p;
    f = (( abs(x) ) .^ p ) ./ p;
    H = sign(x) .* ( abs(x) ) .^ (p - 1);
    W = ( abs(x) ) .^ (p - 2);
end
%
if strcmp(str, 'Fair')
%     c = params.FairC;
%     f = (c .^ 2) .* ((abs(x) ./ c) - log(1 + (abs(x) ./ c)));
%     H = x ./ (1 + (abs(x) ./ c));
%     W = 1 ./ (1 + (abs(x) ./ c));
    c = params.FairC;
    tmp1 = (abs(x) ./ c);
    f = (c .^ 2) .* (tmp1 - log(1 + tmp1));
    W = 1 ./ (1 + tmp1);
    H = x .* W;
end
%
if strcmp(str, 'Huber')
    k = params.HuberK;
    tmpf = [];tmpH = [];tmpW = [];
    for i = 1 : 1 : length(x)
        tx = x(i);
        if abs(tx) <= k
            tf = 0.5 .* (tx .^ 2);
            tH = tx;
            tW = 1;
        else
            tf = k .* (abs(tx) - 0.5 .* k);
            tH = k .* sign(tx);
            tW = k ./ abs(tx);
        end
        tmpf = [tmpf; tf];tmpH = [tmpH; tH];tmpW = [tmpW; tW];
    end
    f = tmpf;
    H = tmpH;
    W = tmpW;
end
%
if strcmp(str, 'Cauchy')
%     c = params.CauchyC;
%     f = (0.5 .* c) .* log(1 + (x ./ c) .^ 2);
%     H = x ./ (1 + (x ./ c) .^ 2);
%     W = 1 ./ (1 + (x ./ c) .^ 2);
    c = params.CauchyC;
    tmp1 = (x ./ c) .^ 2;
    f = (0.5 .* c) .* log(1 + tmp1);
    W = 1 ./ (1 + tmp1);
    H = x .* W;
end
%
if strcmp(str, 'Geman-McClure')
%     f = (x .^ 2) ./ (1 + x .^ 2);
%     H = x ./ ((1 + x .^ 2) .^ 2);
%     W = 1 ./ ((1 + x .^ 2) .^ 2);
    tmp1 = 1 + x .^ 2;
    f = (x .^ 2) ./ tmp1;
    W = 1 ./ (tmp1 .^ 2);
    H = x .* W;
end
%
if strcmp(str, 'Welsch')
%     c = params.WelschC;
%     f = 0.5 .* (c .^ 2) .* (1 - exp( - (x ./ c) .^ 2));
%     H = x .* exp( - (x ./ c) .^ 2);
%     W = exp( - (x ./ c) .^ 2);
    c = params.WelschC;
    tmp1 = exp( - (x ./ c) .^ 2);
    f = 0.5 .* (c .^ 2) .* (1 - tmp1);
    W = tmp1;
    H = x .* W;    
end
%
if strcmp(str, 'Tukey')
    c = params.TukeyC;
    fixedc = ((c .^ 2) ./ 6); % 2022-09-15 modified
    tmpf = [];tmpH = [];tmpW = [];
    for i = 1 : 1 : length(x)
        tx = x(i);
        if abs(tx) <= c
%             tf = ((c .^ 2) ./ 6) .* (1 - (1 - (tx ./ c) .^ 2) .^ 3);
%             tH = tx .* (1 - (tx ./ c) .^ 2) .^ 2;
%             tW = (1 - (tx ./ c) .^ 2) .^ 2;
            tmp0 = (1 - (tx ./ c) .^ 2);
            tmp1 = tmp0 .^ 2;
            tf = fixedc .* (1 - tmp0 .^ 3);
            tW = tmp1;
            tH = tx .* tW;            
        else
            tf = fixedc;
            tH = 0;
            tW = 0;
        end
        tmpf = [tmpf; tf];tmpH = [tmpH; tH];tmpW = [tmpW; tW];
    end
    f = tmpf;
    H = tmpH;
    W = tmpW;
end
%%
[maxW,idx] = max(W);
if maxW == Inf
    tmpM = maxk(W, 2);
    W(idx) = tmpM(end);
end
maxW = max(W);
[minW,idx] = min(W);
if minW == -Inf
    tmpM = mink(W, 2);
    W(idx) = tmpM(end);
end
minW = min(W);
if maxW == minW
    W = W;
else
    W = (W - minW)./(maxW - minW);
end
if isrow(W) %
    W = W';
end
end