function [means, vars] = VoxelGridDown(vPts, voxelSize, rangeLimits, minVoxelPoints)

inverseVoxelSize = 1 / voxelSize;

xmin = rangeLimits(1); xmax = rangeLimits(2);
ymin = rangeLimits(3); ymax = rangeLimits(4);
zmin = rangeLimits(5); zmax = rangeLimits(6);
% Check that the voxel size is not too small, given the size of the data
dx = floor((xmax - xmin) * inverseVoxelSize) + 1;
dy = floor((ymax - ymin) * inverseVoxelSize) + 1;
dz = floor((zmax - zmin) * inverseVoxelSize) + 1;
dxy = dx*dy;  dxyz = dxy*dz;
if (dx == 0 || dy == 0 || dz == 0 || dxy == 0)
    printf('vision:pointcloud:voxelSizeTooSmall');
end
if (dx ~= dxy / dy || dz ~= dxyz / dxy)
    printf('vision:pointcloud:voxelSizeTooSmall');
end
% 
Len = size(vPts, 1);
vvNewPts = vPts(:,1);
vvRawIdx = [];
for n = 1 : 1 : Len
    tmpPt = vPts(n,:);
    tmpdx = floor((tmpPt(1) - xmin) * inverseVoxelSize) + 1;
    tmpdy = floor((tmpPt(2) - ymin) * inverseVoxelSize) + 1;
    tmpdz = floor((tmpPt(3) - zmin) * inverseVoxelSize) + 1;
    vvNewPts(n, :) = tmpdx + tmpdy * dx + tmpdz * dxy;
    vvRawIdx = [vvRawIdx; n];
end
bTest = 1;
[~,~,ic] = unique(vvNewPts, 'rows', 'stable');

Low = min(ic);
Upw = max(ic);

means = [];
vars = [];
vOnePts = [];
for n = Low : 1 : Upw
    validIdx = ic == n;
    if sum(validIdx) < minVoxelPoints
        continue;
    end
    vSelIdxs = vvRawIdx(validIdx);
    vSelvPts = vPts(vSelIdxs, :);
    means(end+1, :) = mean(vSelvPts); %vSelvPts(1,:); %mean(vSelvPts);
    vars(:,:,end+1) = cov(vSelvPts);%cov(vSelvPts);RobustCov
    vOnePts = [vOnePts; vSelvPts(1,:)];
end
vars = vars(:,:,2:end);
% figure;pcshow(means);
bTest = 1;

end


function c = RobustCov(vPts)
center = mean(vPts);
Res = vPts - center;
tmp = sqrt(Res(:,1).^2 + Res(:,2).^2 + Res(:,3).^2);
Idx = tmp >= 1e-6;
tmp = tmp(Idx);
ws = 1 ./ tmp;
ws = ws ./ sum(ws);
c = ((ws .* Res)' * Res);
end
function m = RobustMean(vPts)
center = mean(vPts);
Res = vPts - center;
tmp = sqrt(Res(:,1).^2 + Res(:,2).^2 + Res(:,3).^2);
Idx = tmp >= 1e-6;
tmp = tmp(Idx);
ws = 1 ./ tmp;
ws = ws ./ sum(ws);
m = sum(ws .* vPts);
end