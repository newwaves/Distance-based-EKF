function [Xk, Ck] = UpdataGene(kdMap, ptMap, ptHdl, Xbk, Cbk, XbkTF, ParaS)

coresTF = ParaS.CorresTF;
[vTraPts, vHdlPts, vMapPts, vMapNor] = FindCorrespondences(kdMap, ptMap, ptHdl, coresTF, 1, 100);

NumPts = size(vHdlPts, 1);
if NumPts > 20
    vH = zeros(NumPts, 6);
    vRawD = zeros(NumPts, 1);
    R = XbkTF(1:3, 1:3); % [t R] -> [x,y,z,az,ay,ax]
    T = XbkTF(1:3, end);
    
    for n = 1 : 1 : NumPts
        if ~isempty(vMapNor)
            tmpN = vMapNor(n, :)';
        end
        tmpM = vMapPts(n, :)';
        tmpS = vHdlPts(n, :)';

        if isfield(ParaS, 'DistType') % DistType = {'P2PL1','P2PL2','P2P1','P2P2'};
            DistClass = ParaS.DistType;
        else
            DistClass = 'P2PL1';    % default
        end
        if strcmp(DistClass, 'P2P1')
            pp = R * tmpS + T - tmpM;
            d = sqrt(pp' * pp); %
            if d < 10e-8
                d = 10e-8;
            end
            H = (1 ./ d) .* pp' * [-R * skew(tmpS), eye(3)]; % right successful
        end
        if strcmp(DistClass, 'P2PL1')
            pp = R * tmpS + T - tmpM;
            d = tmpN' * pp; %
            H = tmpN' * [-R * skew(tmpS), eye(3)]; % right successful
        end
        vH(n, :) = H;
        vRawD(n, :) = d;
    end
    %----------------------------------------------------------
    if ParaS.isRobustLoss == 1        % Normalized 2021-08-24
        [vD, ~, vW] = vDistLossFun(vRawD, ParaS.RobustF);
        vW = vW ./ sum(vW);
        vF =  NumPts .* vRawD .* vW;   % weight function = influence function / x;
        vH =  vF .* vH;
    else
        vD = vRawD;
    end
    %----------------------------------------------------------
    isShow = 0;
    if isShow == 1
        vNewW = vW;
        Res = 0.1;
        vC = jet(1 ./ Res + 1);% copper  parula
        figure;hold on;grid on;
        for iii = 1 : 1 : size(vTraPts, 1)
            ddd = floor(vNewW(iii, :) ./ Res) + 1;
            plot3(vTraPts(iii,1), vTraPts(iii,2), vTraPts(iii,3), '.', 'Color', vC(ddd,:), 'MarkerSize', 10);hold on;
        end
        pcshow(ptMap);view(2);box on;
    end
    %%
    % Xbk - % [x,y,z,az,ay,ax] convert to [ax,ay,az, x, y, z]' -  [R, t]
    tmpXb = [Xbk(6);Xbk(5);Xbk(4);Xbk(1:3)]; % [ax,ay,az, x, y, z]' very key!
    %tmpTF = XbkTF;
    %%
    Qk = ParaS.ScaleC .* ParaS.QCov; %% modified @Home,2021-10-18
    %%
    for i = 1 : 1 : size(vD,1)  % X = [R,t]
        Sk = vH(i,:) * Cbk * vH(i,:)' + Qk;
        Kk = Cbk * vH(i,:)' / Sk;
        tmpXb = tmpXb + Kk * ( 0 - vD(i,:)'); % oPlus more robust!
        Cbk = (eye(6) - Kk * vH(i,:)) * Cbk;
    end
    %-----------------------------------------------------
    Xk = [tmpXb(4:6); wrapToPi(tmpXb(3)); wrapToPi(tmpXb(2)); wrapToPi(tmpXb(1))];% convert to [x,y,z,az,ay,ax]'
    Ck = Cbk;
    %-----------------------------------------------------
else
    Xk = Xbk;
    Ck = Cbk;
end
end
