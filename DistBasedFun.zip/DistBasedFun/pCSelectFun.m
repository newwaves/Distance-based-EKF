function ptHdl = pCSelectFun(sFrm, NumvPts)

if NumvPts == 250
    ptHdl = sFrm.pc250;
elseif NumvPts == 1000
    ptHdl = sFrm.pc1000;
elseif NumvPts == 2000
    ptHdl = sFrm.pc2000;
elseif NumvPts == 4000
    ptHdl = sFrm.pc4000;
elseif NumvPts == 8000
    ptHdl = sFrm.pc8000;
end
% ptHdl = sFrm.ptHdl; % 2000 points

end