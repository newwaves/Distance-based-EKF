function [XbkTF, Xbk, Gx, Gu] = PropagationTF( nFrm, Xk_1, ParaS )
%UNTITLED12 此处显示有关此函数的摘要
%   此处显示详细说明

% Motion model

if ParaS.isFirst == 1  %nFrm == 1
    Xbk = Xk_1; % x,y,z,az,zy,zx
    Gx = eye(6);
    Gu = zeros(6,6);
else
    % B = load('KITTI00/OdoPose.mat');
    if size(ParaS.vImuTF, 3) > 500 && ParaS.dFrm >= 2
        PreTF = ParaS.vImuTF(:,:,nFrm - ParaS.dFrm) * ParaS.CalTF; % convert to LiDAR system
        CurTF = ParaS.vImuTF(:,:,nFrm)              * ParaS.CalTF;
    else
        % B = load('KITTI00/OdoPosedF5.mat');
        PreTF = ParaS.vImuTF(:,:,nFrm - 1) * ParaS.CalTF; % convert to LiDAR system
        CurTF = ParaS.vImuTF(:,:,nFrm)     * ParaS.CalTF;
    end
    [Xbk, Gx, Gu] = MotionModel3D( Xk_1, PreTF, CurTF, ParaS );
end
% Y Must be effective
TmpQ = eul2quat(Xbk(4:6)');
TmpR = quat2rotm(TmpQ);
TmpR = eul2rotm(rotm2eul(TmpR));
TmpT = Xbk(1:3);
XbkTF = [TmpR,TmpT;0 0 0 1];

end

%%

function [G, Gx, Gu] = MotionModel3D( X, PreTF, CurTF, ParaS )
if nargin < 3
    ParaS.isLeft = 1;
end
% motion model, which is also called predict model
% where the control variable is defined [DeltaRot1, DeltaTran, DeltaRot2]';
Tf0 = CPose2TF(X);
% PreTF = CPose2TF(PreOdometryPose');
% CurTF = CPose2TF(CurOdometryPose');
DifTF = PreTF \ CurTF; % inv(PreTF) * CurTF;
NewTf = Tf0 * DifTF;
G = CTF2Pose(NewTf); % x,y,z,az,zy,zx
%%
% % % % % % % [R,t] is defined as [ax,ay,az,x,y,z]
if nargout > 1
    Rk_1 = Tf0(1:3,1:3);
    dRk = DifTF(1:3,1:3);
    dTk = DifTF(1:3,end);
    
    Gx = [             dRk', zeros(3);... % dRk' is right-multiple operate
        - Rk_1 * skew(dTk),  eye(3)];    % - Rk_1 * skew(dTk) is right-multiple
    Gu = [eye(3), zeros(3);... % [dR,dt]  % eye(3)    is right-multiple operate
        zeros(3), Rk_1];
end

end

