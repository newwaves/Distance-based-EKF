function [vars, invars, ptHdl] = ScansCovVoxelGrid(ptOrg, GridSize, isMyCovV)
% Ndt type map, is successful in localization
% not real-time
if nargin < 3
    isMyCovV = 0;
end

if isMyCovV == 1 % the performance is higher than the below.
    [~, vars, invars, ptHdl] = VoxelGridMeanCovFun(ptOrg, GridSize);
else
    % pcregisterndt method, very fast. why???
    [means, invars, vars] = vision.internal.pc.voxelGridFilter(...
        ptOrg.Location, GridSize, 6, 100);
    ptHdl = pointCloud(means);
end

end