function [vars, invars, ptTmp] = ScansCovNeibK(ptHdl, ptOrg, NeibK)
% k-NN search method, is successful in localization
kdMap = createns(ptOrg.Location);
[vvIdx, ~] = knnsearch(kdMap, ptHdl.Location, 'k', NeibK ); % NeibK = 10 default
%%
vars = nan(3, 3, ptHdl.Count);
for n = 1 : 1 : ptHdl.Count
    vIdx = vvIdx(n, :); 
    Cov = cov( ptOrg.Location(vIdx, :) );    
    vars(:, :, n) = Cov;
end
means = ptHdl.Location;
% normals = ptHdl.Normal;
invars = nan(size(vars), 'like', vars);
invalid = false(size(means));
eigenValueRatio = 100;      % Flat the covariance to avoid singularity
for n = 1 : size(vars, 3)
    if any(~isfinite(vars(:,:,n)))
        invalid(n) = true;
        continue;
    end    
    % Eigenvectors corresponding to distinct eigenvalues of a symmetric
    % matrix must be orthogonal to each other.
    [V, D] = eig(vars(:,:,n), 'vector');    
    maxEv = max(D);
    flat = (maxEv >= D * eigenValueRatio);    
    if any(flat)
        D(flat) = maxEv / eigenValueRatio;        
        J = V * V' - eye(3);
        if max(abs(J(:))) < 10*eps(class(J))
            iV = V';
        else
            iV = inv(V);
        end        
        vars(:,:,n) = real(V * diag(D) * iV);
        invars(:,:,n) = real(V * diag(1./D) * iV);
    else
        invars(:,:,n) = inv(vars(:,:,n));
    end
end
%%
means(invalid, :)     = [];
% normals(invalid, :)   = [];
ptTmp = pointCloud(means);
% ptTmp.Normal = normals;

invars(:, :, invalid) = [];
vars(:, :, invalid)   = [];
end