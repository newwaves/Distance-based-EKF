function [vTraPts, vHdlPts, vMapPts, vMapCov, vHdlCov] = FindCorrespondencesPtsCov(PtsCovArg, ptHdl, InitTF, InlierRatio, DistThr, ParaS)

vtranPts = myRigidTransform(ptHdl.Location, InitTF(1:3,1:3), InitTF(1:3,end));
%%
upperBoundRatio = max(1, round(InlierRatio(1) * ptHdl.Count)); 
%Find the correspondence
[indices, dists] = PtsCovArg.subkdMap.knnsearch(vtranPts, 'dist','euclidean');
% Remove outliers
keepInlierA = false(ptHdl.Count, 1);
[~, idx] = sort(dists);
upperBoundDist = length(find(dists < DistThr)); % very important parameters 2020-05-04
upperBound = min(upperBoundRatio, upperBoundDist); % added 2020-11-03
keepInlierA(idx(1:upperBound)) = true;
inlierIndicesB = indices(keepInlierA);

vTraPts = vtranPts(keepInlierA,:); % Here is different from CorrectStepModel
vHdlPts = ptHdl.Location(keepInlierA,:);
vHdlCov = PtsCovArg.ptHdlCovs(:, :, keepInlierA);
% vHdlInvCov = PtsCovArg.ptHdlInvCovs(:, :, keepInlierA);

vMapPts = PtsCovArg.subMap.Location(inlierIndicesB,:);
vMapCov = PtsCovArg.subvCovs(:, :, inlierIndicesB);
% vMapInvCov = PtsCovArg.invvCovs(:, :, inlierIndicesB);
end