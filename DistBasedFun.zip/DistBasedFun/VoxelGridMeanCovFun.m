function [means, vars, invars, ptHdl] = VoxelGridMeanCovFun(ptMap, voxelSize, minVoxelPoints, eigenValueRatio)
vPts = ptMap.Location;
if nargin < 3
    % Voxelize the reference point cloud
    minVoxelPoints = 6;         % Remove voxels that contain less than 6 points
    eigenValueRatio = 100;      % Flat the covariance to avoid singularity
end

rangeLimits = [...
    min(vPts(:,1)),max(vPts(:,1)), ...
    min(vPts(:,2)),max(vPts(:,2)),...
    min(vPts(:,3)),max(vPts(:,3))];

[means, vars] = VoxelGridDown(vPts, voxelSize, rangeLimits, minVoxelPoints);
invars = nan(size(vars), 'like', vars);
invalid = false(size(means));
   
for n = 1 : size(means, 1)
    if any(~isfinite(vars(:,:,n)))
        invalid(n) = true;
        continue;
    end
    
    % Eigenvectors corresponding to distinct eigenvalues of a symmetric
    % matrix must be orthogonal to each other.
    [V, D] = eig(vars(:,:,n),'vector');
    
    maxEv = max(D);
    flat = (maxEv >= D * eigenValueRatio);
    
    if any(flat)
        D(flat) = maxEv / eigenValueRatio;
        
        J = V * V' - eye(3);
        if max(abs(J(:))) < 10*eps(class(J))
            iV = V';
        else
            iV = inv(V);
        end
        
        vars(:,:,n) = real(V * diag(D) * iV);
        invars(:,:,n) = real(V * diag(1./D) * iV);
    else
        invars(:,:,n) = inv(vars(:,:,n));
    end
end

means(invalid, :)     = [];
invars(:, :, invalid) = [];
vars(:, :, invalid)   = [];
ptHdl = pointCloud(means);
end